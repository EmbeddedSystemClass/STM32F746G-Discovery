/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32F7xx_HAL_Examples
  * @{
  */

/** @addtogroup Templates
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define LEDtoggle 0

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
osThreadId LED1_ThreadId;
osTimerId lcd_timer;

uint32_t counter = 0;
uint8_t str[30];
char strBuff[128];
U8 _acBuffer[2000];

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void Error_Handler(void);
static void MPU_Config(void);
static void CPU_CACHE_Enable(void);
static void LED_Thread1(void const *argument);
static void TimerCallback(void const *n);
static void GUIThread(void const * argument);
static int APP_GetData(void * p, const U8 * * ppData, unsigned NumBytesReq, U32 Off);

/* Private functions ---------------------------------------------------------*/

#if defined ( __ICCARM__ ) /*!< IAR Compiler */
#pragma location=0x20006024
uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];
#elif defined ( __CC_ARM )
uint8_t ucHeap[ configTOTAL_HEAP_SIZE ] __attribute__((at(0x20006024)));
#elif defined ( __GNUC__ ) 
uint8_t ucHeap[ configTOTAL_HEAP_SIZE ] __attribute__((section(".RamData2")));
#endif

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  /* This project template calls firstly two functions in order to configure MPU feature 
     and to enable the CPU Cache, respectively MPU_Config() and CPU_CACHE_Enable().
     These functions are provided as template implementation that User may integrate 
     in his application, to enhance the performance in case of use of AXI interface 
     with several masters. */ 
  
  /* Configure the MPU attributes as Write Through */
  MPU_Config();

  /* Enable the CPU Cache */
  CPU_CACHE_Enable();

  /* STM32F7xx HAL library initialization:
       - Configure the Flash ART accelerator on ITCM interface
       - Configure the Systick to generate an interrupt each 1 msec
       - Set NVIC Group Priority to 4
       - Low Level Initialization
     */
  HAL_Init();

  /* Configure the System clock to have a frequency of 216 MHz */
  SystemClock_Config();
	
	k_BspInit(); 
	
	/* Initialize LEDs */
  BSP_LED_Init(LED1);
	
	/* Initialize SD */
	BSP_SD_Init();
	
	/* Initialize GUI */
  GUI_Init();   
  
  WM_MULTIBUF_Enable(1);
  GUI_SetLayerVisEx (1, 0);
  GUI_SelectLayer(0);
  
  GUI_SetBkColor(GUI_BLACK);
  GUI_Clear(); 
	
	/* Create GUI task */
  osThreadDef(GUI_Thread, GUIThread, osPriorityNormal, 0, 2048);
  osThreadCreate (osThread(GUI_Thread), NULL); 
	
  /* Create Touch screen Timer */
  osTimerDef(TS_Timer, TimerCallback);
  lcd_timer =  osTimerCreate(osTimer(TS_Timer), osTimerPeriodic, (void *)0);

  /* Start the TS Timer */
  osTimerStart(lcd_timer, 100);
  
  /* Thread 1 definition */
  osThreadDef(LEDtoggle, LED_Thread1, osPriorityNormal, 0, configMINIMAL_STACK_SIZE);
  
  /* Start thread 1 */
  LED1_ThreadId = osThreadCreate(osThread(LEDtoggle), NULL);
  
  /* Start scheduler */
  osKernelStart();
  
  /* We should never get here as control is now taken by the scheduler */
  for(;;);
}

/**
  * @brief  Start task
  * @param  argument: pointer that is passed to the thread function as start argument.
  * @retval None
  */
static void GUIThread(void const * argument)
{
	char SD_Path[4]; /* SD card logical drive path */
	FATFS fs;
	FILINFO fno;
	DIR dir;
	FIL F1;
	FRESULT res;
	
	while(1)
	{
		GUI_SetLayerVisEx (0, 1);
		GUI_SetLayerVisEx (1, 0);
		GUI_SelectLayer(0);
  
		GUI_SetColor(GUI_WHITE);
		GUI_SetBkColor(GUI_BLACK);
		GUI_Clear(); 
		
		GUI_SetFont(&GUI_Font24_ASCII);

		while(BSP_SD_IsDetected() != SD_PRESENT)
		{
			GUI_Clear();
			GUI_SetColor(GUI_RED);
			GUI_DispStringAt("Please insert SD Card", 16, 16);
			osDelay(500);
		}
			
		osDelay(100);
		
		/* Initialize SD */
		BSP_SD_Init();
		
		if(FATFS_LinkDriver(&SD_Driver, SD_Path) == 0)
		{
			uint32_t counter = 0;
			
			f_mount(&fs, (TCHAR const*)"", 0);
			f_opendir(&dir, "/Media");
			for (;;)
			{
				res = f_readdir(&dir, &fno);
				
				if (res != FR_OK || fno.fname[0] == 0)
					break;
				if (fno.fname[0] == '.')
					continue;

				if (!(fno.fattrib & AM_DIR))
				{
					do
					{
						counter++;
					}
					while (fno.fname[counter] != '.');
					
					// Format the string 
					sprintf ((char*)str, "Media/%-11.11s", fno.fname);

					GUI_SetColor(GUI_WHITE);
					GUI_SetBkColor(GUI_BLACK);
					GUI_Clear(); 
					
					f_open(&F1, (TCHAR const*)str, FA_READ);
					
					if ((fno.fname[counter + 1] == 'B') && (fno.fname[counter + 2] == 'M') && (fno.fname[counter + 3] == 'P'))
						GUI_BMP_DrawEx(APP_GetData, &F1, 0, 0);
					
					if ((fno.fname[counter + 1] == 'J') && (fno.fname[counter + 2] == 'P') && (fno.fname[counter + 3] == 'G'))
						GUI_JPEG_DrawEx(APP_GetData, &F1, 0, 0);
					
					if ((fno.fname[counter + 1] == 'J') && (fno.fname[counter + 2] == 'P') && (fno.fname[counter + 3] == 'E') && (fno.fname[counter + 4] == 'G'))
						GUI_JPEG_DrawEx(APP_GetData, &F1, 0, 0);
					
					if ((fno.fname[counter + 1] == 'G') && (fno.fname[counter + 2] == 'I') && (fno.fname[counter + 3] == 'F'))
						GUI_GIF_DrawEx(APP_GetData, &F1, 0, 0);
					
					
					f_close(&F1);
									
					GUI_DispStringAt((TCHAR const*)str, 16, 16);
				
					osDelay(1000);
					
					counter = 0;
				}
			}
			f_mount(NULL, (TCHAR const*)"",0);
		}
	}
}


int APP_GetData(void * p, const U8 * * ppData, unsigned NumBytesReq, U32 Off)
{
	FIL * phFile;
	UINT NumBytesRead;
	
	//f_open(&phFile, (TCHAR const*)p, FA_READ);
	phFile = (FIL *) p;
	//GUI_Clear();
	//sprintf(strBuff, "file: %s, req: %u, offset: %u\n", (TCHAR const*)p, NumBytesReq, Off);
	//GUI_DispStringAt(strBuff, 16, 16);
	//osDelay(500);
	
	// Check buffer size
	if (NumBytesReq > sizeof(_acBuffer)) {
		NumBytesReq = sizeof(_acBuffer);
	}
	
	// Set file pointer to the offset location
	f_lseek(phFile, Off);
	
	// Read data into buffer
	f_read(phFile, _acBuffer, NumBytesReq, (UINT *)&NumBytesRead);
	
	// Set data pointer to the beginning of the buffer
	*ppData = _acBuffer;
	
	// Close file
	//f_close(&phFile);

	// Return number of available bytes
	return NumBytesRead;
}

/**
  * @brief  Timer callbacsk (40 ms)
  * @param  n: Timer index 
  * @retval None
  */
static void TimerCallback(void const *n)
{  
  k_TouchUpdate();
}

/**
  * @brief  Toggle LED1 thread
  * @param  Thread not used
  * @retval None
  */
static void LED_Thread1(void const *argument)
{
  (void) argument;
  uint32_t PreviousWakeTime = osKernelSysTick();
  
  for(;;)
  {
/* osDelayUntil function differs from osDelay() in one important aspect:  osDelay () will
 * cause a thread to block for the specified time in ms from the time osDelay () is
 * called.  It is therefore difficult to use osDelay () by itself to generate a fixed
 * execution frequency as the time between a thread starting to execute and that thread
 * calling osDelay () may not be fixed [the thread may take a different path though the
 * code between calls, or may get interrupted or preempted a different number of times
 * each time it executes].
 *
 * Whereas osDelay () specifies a wake time relative to the time at which the function
 * is called, osDelayUntil () specifies the absolute (exact) time at which it wishes to
 * unblock.
 * PreviousWakeTime must be initialised with the current time prior to its first use 
 * (PreviousWakeTime = osKernelSysTick() )   
 */  
    osDelayUntil (&PreviousWakeTime, 500);
    BSP_LED_Toggle(LED1);
		/*
		osDelayUntil (&PreviousWakeTime, 500);
		GUI_SetColor(GUI_BLACK);
		GUI_FillCircle(128, 272/2, 8*3);
    BSP_LED_Toggle(LED1);
		*/
  }
}


/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 216000000
  *            HCLK(Hz)                       = 216000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 4
  *            APB2 Prescaler                 = 2
  *            HSE Frequency(Hz)              = 25000000
  *            PLL_M                          = 25
  *            PLL_N                          = 432
  *            PLL_P                          = 2
  *            PLL_Q                          = 9
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale1 mode
  *            Flash Latency(WS)              = 7
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_OFF;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 432;  
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* activate the OverDrive to reach the 216 Mhz Frequency */
  if(HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }
  
  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  
  if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
static void Error_Handler(void)
{
  /* User may add here some code to deal with this error */
  while(1)
  {
  }
}

/**
  * @brief  Configure the MPU attributes as Write Through for SRAM1/2.
  * @note   The Base Address is 0x20010000 since this memory interface is the AXI.
  *         The Region Size is 256KB, it is related to SRAM1 and SRAM2  memory size.
  * @param  None
  * @retval None
  */
static void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct;
  
  /* Disable the MPU */
  HAL_MPU_Disable();

  /* Configure the MPU attributes as WT for SRAM */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.BaseAddress = 0x20010000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_256KB;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_CACHEABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.SubRegionDisable = 0x00;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_ENABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /* Enable the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/**
  * @brief  CPU L1-Cache enable.
  * @param  None
  * @retval None
  */
static void CPU_CACHE_Enable(void)
{
  /* Enable I-Cache */
  SCB_EnableICache();

  /* Enable D-Cache */
  SCB_EnableDCache();
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
