//----------------------------------------------
//  Modified by MIKAMI, 2016/01/05
//----------------------------------------------

#include "mbed.h"
#include "functions_for_audio.hpp"
#include "LCD_DISCO_F746NG.h"
#include "button_group.hpp"
#include "WaveformDisplay.hpp"
#include "AnalysisSelector.hpp"

const int N_DATA_ = 260;                    // Number of data to be analyzed
const int BufferSize = (N_DATA_*2 + 1)*4;   // Sample Size for input data

extern int16_t audio_in_buffer[BufferSize];
extern __IO bool audio_in_buffer_captured;
extern __IO int32_t audio_in_buffer_offset;
extern __IO int32_t audio_in_buffer_length;
