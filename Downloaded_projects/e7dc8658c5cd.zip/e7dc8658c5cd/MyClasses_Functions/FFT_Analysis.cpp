//-------------------------------------------------------
//  Class for spectrum analysis using FFT
//
//  2015/12/15, Copyright (c) 2015 MIKAMI, Naoki
//-------------------------------------------------------

#include "FFT_Analysis.hpp"

namespace Mikami
{
    FftAnalyzer::FftAnalyzer(int nData, int nFft)
        : AnalyzerBase(nData, nFft, nFft),
          yFft_(new Complex[nFft/2+1]) {}

    FftAnalyzer::~FftAnalyzer()
    {
        delete[] yFft_;
    }

    void FftAnalyzer::Analyze(const float xn[], float yn[])
    {
        fft_.Execute(xn, yFft_);    // Execute FFT
        
        // Translate to dB
        for (int n=0; n<=N_FFT_/2; n++)
            yn[n] = 10.0f*log10f(Norm(yFft_[n]));
    }
}
