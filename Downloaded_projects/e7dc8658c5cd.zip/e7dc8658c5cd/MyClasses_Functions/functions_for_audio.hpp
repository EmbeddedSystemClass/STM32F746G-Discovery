//---------------------------------------------------------------
//  Functions for audio device on DISCO-F746NG and etc. (Header)
//  2016/01/06, Copyright (c) 2016 MIKAMI, Naoki
//---------------------------------------------------------------

#include "stm32746g_discovery_audio.h"

#ifndef FUNCTIONS_FOR_AUDIO_HPP
#define FUNCTIONS_FOR_AUDIO_HPP

void InitRunAudioIn(uint16_t inputDevice, int samplingFreq);
void StopAudioIn();
static void init_audio_in(uint16_t InputDevice, int SamplingFreq);
static void record_audio_in();

void error_trap();

namespace Mikami
{
    void Decimate(int dataNum, int index, const int16_t xn[], int16_t sn[]);
}

#endif  // FUNCTIONS_FOR_AUDIO_HPP