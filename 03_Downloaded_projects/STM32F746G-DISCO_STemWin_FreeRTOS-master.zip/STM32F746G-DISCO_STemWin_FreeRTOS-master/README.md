This project based on HAL library and have some dependencies from BSP functions.
The project was created in Attolic Truestudio IDE.
Hardware is a stock STM32F746G-DISCOVERY development board from stmicroelectronics. 
This example using FreeRTOS operating system. Show how to use RTOS and STemWin together. 
The used window layout was created with stemwin's GUIbuilder application.
![img_8674](https://user-images.githubusercontent.com/41072101/52897564-88d60300-31d6-11e9-8539-87a3087fc968.JPG)   