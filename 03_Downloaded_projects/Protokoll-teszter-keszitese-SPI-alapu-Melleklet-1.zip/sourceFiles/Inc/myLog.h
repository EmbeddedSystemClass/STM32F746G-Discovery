#ifndef __MYLOG_H
#define __MYLOG_H

#include "sd.h"

//void myLog(char* filename, char* text, uint16_t value);

#endif // __MYLOG_H
