#ifndef __ACCSENSOR_H
#define __ACCSENSOR_H

#include "stdint.h"
#include "expat.h"

typedef enum{
	READ,
	READ_WRITE
} ReadWrite;

typedef struct{
	char name[20];
	char address[20];
	ReadWrite rw;
}accSensorRegister;

typedef struct{
	accSensorRegister registers[50];
	uint8_t regCount;
	uint8_t axises[3]; //stores which axeses are available | [0]=x , [1]=y , [2]=z
}accSensor;

accSensor sensor;

static void XMLCALL
     start(void *data, const XML_Char *el, const XML_Char **attr);
static void XMLCALL
     end(void *data, const XML_Char *el);

static void XMLCALL
     characterDataHandler(void *data, const XML_Char *s, int len);

uint8_t InitSensor();

#endif // __ACCSENSOR_H
