#ifndef __SD_H
#define __SD_H

//#include "main.h"

//#include "stm32746g_discovery_sd.h"
#include "ff_gen_drv.h"
#include "sd_diskio.h"


FRESULT mount();
FRESULT readFromSD(char* filename, char* buff, uint16_t size);
FRESULT writeToSD(char* filename, char* buff, uint16_t size);
FRESULT writeToSDAppend(char* filename, char*buff, uint16_t size);
FRESULT checkFile(char* filename);
FRESULT createEmptyFile(char* filename);
uint8_t getFiles(uint8_t n, uint8_t m, char fnames[n][m]);

#endif // __SD_H
