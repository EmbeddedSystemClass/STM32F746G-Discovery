#ifndef __TEST_SEQUENCE_H
#define __TEST_SEQUENCE_H

#include "expat.h"
#include "spi.h"

typedef enum{
	CMD_READ,
	CMD_WRITE,
	CMD_DELAY,
	CMD_CHECK
} TEST_CMD;




static void XMLCALL
     start(void *data, const XML_Char *el, const XML_Char **attr);
static void XMLCALL
     end(void *data, const XML_Char *el);

static void XMLCALL
     characterDataHandler(void *data, const XML_Char *s, int len);

uint8_t initSteps(char* buff);
uint8_t runTest(char* filename, uint8_t startup);


#endif // __TEST_SEQUENCE_H
