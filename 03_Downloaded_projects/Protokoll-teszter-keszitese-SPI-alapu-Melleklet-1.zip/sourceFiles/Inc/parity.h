#ifndef __PARITY_H
#define __PARITY_H

uint8_t calculateOddParity(uint8_t data);

#endif // __MYLOG_H
