#ifndef __SPI_H
#define __SPI_H

#include "stdint.h"
#include "stm32f7xx_hal.h"

void SPI_init();
//void startUp();
int16_t readXaxis(uint8_t LSBaddr, uint8_t MSBaddr);
int16_t readYaxis(uint8_t LSBaddr, uint8_t MSBaddr);
int16_t readZaxis(uint8_t LSBaddr, uint8_t MSBaddr);
uint16_t getTemp();
uint16_t readReg(uint16_t addr, char* err);
uint16_t readRegFULL(uint16_t addr);
uint16_t writeReg(uint16_t addr, uint16_t value);

#endif // __SPI_H
