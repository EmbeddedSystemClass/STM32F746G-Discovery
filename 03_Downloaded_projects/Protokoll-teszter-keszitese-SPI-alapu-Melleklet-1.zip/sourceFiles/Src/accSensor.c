#include "accSensor.h"
#include "sd.h"


char Buff[1500];
char tagData[50];
int Depth=0;
uint8_t idx=0;
uint8_t reg_nameTagFound=0;
uint8_t reg_addressTagFound=0;
uint8_t rwTagFound=0;
uint8_t regCountTagFound=0;
enum XML_Status status;

uint8_t InitSensor(char* filename){
	readFromSD(filename,Buff,1500);
	XML_Parser parser=XML_ParserCreate(NULL);
	XML_SetUserData(parser, &Depth);
	XML_SetElementHandler(parser, start, end);
	XML_SetCharacterDataHandler(parser,characterDataHandler);
	status=XML_Parse(parser, Buff, strlen(Buff), 1);
	XML_ParserFree(parser);
	if (status!=XML_STATUS_OK){
		return 1;
	}
	else{
		return 0;
	}
}

static void XMLCALL
    start(void *data, const XML_Char *el, const XML_Char **attr)
    {
      int i;
      (void)data;

      //el parameter contains the name of the xml tag
      if (strcmp(el,"name")==0){
    	  reg_nameTagFound=1;
      }
      if (strcmp(el,"address")==0){
    	  reg_addressTagFound=1;
      }
      if (strcmp(el,"rw")==0){
    	  rwTagFound=1;
      }
      if (strcmp(el,"regCount")==0){
		   regCountTagFound=1;
      }
      Depth++;
    }

    //get called when an xml closing tag detected
    static void XMLCALL
    end(void *data, const XML_Char *el)
    {
      (void)data;
      (void)el;

      if (strcmp(el,"register")==0){
    	  idx++;
      }

      Depth--;
    }


    static void XMLCALL
    characterDataHandler(void *data, const XML_Char *s, int len)
    {
      int i;
      (void)data;

      if (reg_nameTagFound==1){
    	  reg_nameTagFound=0;
		   for (i=0; i<len; i++){
			   //s contains the value of the tag
			   //eg: <name>Peter</name>  ->  s="Peter"
			   sensor.registers[idx].name[i]=s[i];
		   }
		   sensor.registers[idx].name[len]='\0';
		   if (sensor.registers[idx].name[0]=='X'){
			   sensor.axises[0]=1;
		   }
		   if (sensor.registers[idx].name[0]=='Y'){
		   	   sensor.axises[1]=1;
		   }
		   if (sensor.registers[idx].name[0]=='Z'){
		   	   sensor.axises[2]=1;
		   }
      }
      if (reg_addressTagFound==1){
    	  reg_addressTagFound=0;
		   for (i=0; i<len; i++){
			   sensor.registers[idx].address[i]=s[i];
		   }
		   sensor.registers[idx].address[len]='\0';
      }
      if (rwTagFound==1){
		   rwTagFound=0;
		   for (i=0; i<len; i++){
			   tagData[i]=s[i];
		   }
		   tagData[len]='\0';
		   if (strcmp(tagData,"R")==0){
			   sensor.registers[idx].rw=READ;
		   }
		   else if (strcmp(tagData,"RW")==0){
			   sensor.registers[idx].rw=READ_WRITE;
		   }
      }
      if (regCountTagFound==1){
    	  regCountTagFound=0;
    	  for (i=0; i<len; i++){
    		  tagData[i]=s[i];
		  }
		  tagData[len]='\0';
    	  sensor.regCount=atoi(tagData);
      }
    }
