#include "spi.h"
#include "parity.h"

#include "stm32f7xx_hal.h"

SPI_HandleTypeDef SpiHandle;
char err[25];

void SPI_init(){
	SpiHandle.Instance               = SPI2;
	SpiHandle.Init.Mode              = SPI_MODE_MASTER;
	SpiHandle.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
	SpiHandle.Init.Direction         = SPI_DIRECTION_2LINES;
	SpiHandle.Init.CLKPhase          = SPI_PHASE_1EDGE;
	SpiHandle.Init.CLKPolarity       = SPI_POLARITY_HIGH;
	SpiHandle.Init.DataSize          = SPI_DATASIZE_16BIT;
	SpiHandle.Init.FirstBit          = SPI_FIRSTBIT_MSB;
	SpiHandle.Init.TIMode            = SPI_TIMODE_DISABLE;
	SpiHandle.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
	SpiHandle.Init.CRCPolynomial     = 7;
	SpiHandle.Init.NSS               = SPI_NSS_SOFT;

	if(HAL_SPI_Init(&SpiHandle) != HAL_OK)
		  {
			/* Initialization Error */
			Error_Handler();
		  }
}

int16_t readXaxis(uint8_t LSBaddr, uint8_t MSBaddr){
	uint16_t X_lsb=0;
	uint16_t X_msb=0;

	X_lsb=readReg(LSBaddr,err);
	X_msb=readReg(MSBaddr,err);

	if (strcmp(err,"SPI Saturation error")==0){
		return 0;
	}
	else{
		return ((X_msb << 8) & 0xFF00) | (X_lsb & 0x00ff);
	}
}

int16_t readYaxis(uint8_t LSBaddr, uint8_t MSBaddr){
	uint16_t Y_lsb=0;
	uint16_t Y_msb=0;

	Y_lsb=readReg(LSBaddr,err);
	Y_msb=readReg(MSBaddr,err);

	if (strcmp(err,"SPI Saturation error")==0){
		return 0;
	}
	else{
		return ((Y_msb << 8) & 0xFF00) | (Y_lsb & 0x00ff);
	}
}

int16_t readZaxis(uint8_t LSBaddr, uint8_t MSBaddr){
	uint16_t Z_lsb=0;
	uint16_t Z_msb=0;

	Z_lsb=readReg(LSBaddr,err);
	Z_msb=readReg(MSBaddr,err);

	if (strcmp(err,"SPI Saturation error")==0){
		return 0;
	}
	else{
		return ((Z_msb << 8) & 0xFF00) | (Z_lsb & 0x00ff);
	}
}

uint16_t getTemp(){
	uint16_t addr;
	uint16_t temp_lsb=0;
	uint16_t temp_msb=0;
	uint16_t tempdec;
	addr=0b0100110000000000; //temp msb
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_RESET); //cs
	if (HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t*)&addr, (uint8_t *)&temp_msb, 1,100)!=HAL_OK){
		Error_Handler();
	}
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_SET);

	addr=0b0100100100000000; //temp lsb
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_RESET); //cs
	if (HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t*)&addr, (uint8_t *)&temp_lsb, 1,100)!=HAL_OK){
		Error_Handler();
	}
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_SET);

	temp_msb &= 0b0000000000111111;
	temp_lsb &= 0b0000000011110000;
	temp_msb <<=4;
	temp_lsb >>= 4;
	tempdec= temp_msb | temp_lsb;
	return 23+((tempdec-512)/3.2);
}

//read register
//returns just the value of the register
uint16_t readReg(uint16_t addr, char* err){
	uint16_t value=0;
	uint8_t par=0;
	uint8_t frameBits=0;
	addr <<= 2;
	addr &= 0b11111100;
	par=calculateOddParity(addr);
	addr |= par;
	addr <<= 8;
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_RESET); //cs
	if (HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t*)&addr, (uint8_t *)&value, 1,100)!=HAL_OK){
		Error_Handler();
	}
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_SET);

	//check SPI frame bits
	frameBits=(value & 0xFF00) >> 8;
	par=calculateOddParity(value & 0x00FF);
	//par=1;
	if ((frameBits & 0b01000000) !=0){
		sprintf(err,"SPI Frame error");
	}
	else if ((frameBits & 0b00100000) !=0){
		sprintf(err,"SPI PORST bit = 1");
	}
	else if ((frameBits & 0b00010000) !=0){
		sprintf(err,"Self test error");
	}
	else if ((frameBits & 0b00001000) !=0){
		sprintf(err,"SPI Saturation error");
	}
	else if ((frameBits & 0b00000100) !=0){
		sprintf(err,"SPI fixed bit error");
	}
	else if ((frameBits & 0b00000010) ==0){
		sprintf(err,"SPI fixed bit error");
	}
	else if (par != (frameBits & 0b00000001)){
		sprintf(err,"SPI Parity error");
	}
	else{
		sprintf(err,"no error");
	}
	return (value & 0x00FF);
}

//reads register
//returns the full spi frame
uint16_t readRegFULL(uint16_t addr){
	uint16_t value;
	uint8_t par=0;
	addr <<= 2;
	addr &= 0b11111100;
	par=calculateOddParity(addr);
	addr |= par;
	addr <<= 8;
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_RESET); //cs
	if (HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t*)&addr, (uint8_t *)&value, 1,100)!=HAL_OK){
		Error_Handler();
	}
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_SET);
	return value;
}

//writes register
uint16_t writeReg(uint16_t addr, uint16_t value){
	uint8_t par=0;
	uint16_t retval;
	addr <<= 2;
	addr |= 0b00000010;
	addr &= 0b11111110;
	par=calculateOddParity(addr);
	addr |= par;
	addr <<= 8;
	addr |= value;
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_RESET);
	if (HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t*)&addr, (uint8_t *)&retval, 1,100)!=HAL_OK){
		Error_Handler();
	}
	HAL_GPIO_WritePin(GPIOI,GPIO_PIN_0,GPIO_PIN_SET);
	return retval;
}
