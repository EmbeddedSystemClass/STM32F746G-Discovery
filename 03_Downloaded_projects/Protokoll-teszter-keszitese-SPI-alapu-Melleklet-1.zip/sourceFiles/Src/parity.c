#include "stdint.h"
#include "parity.h"

//returns 1 if data has even number of 1
uint8_t calculateOddParity(uint8_t data){
	uint8_t i;
	uint8_t count=0;
	uint8_t mask=0b10000000;
	for (i=0; i<8; i++){
		if ((data & mask)>0){
			count++;
		}
		mask >>= 1;
	}
	if (count%2==0){
		return 1;
	}
	else{
		return 0;
	}
}
