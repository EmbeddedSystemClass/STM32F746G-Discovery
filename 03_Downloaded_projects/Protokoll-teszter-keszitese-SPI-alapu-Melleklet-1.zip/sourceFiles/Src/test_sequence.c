#include "test_sequence.h"
#include "myLog.h"



typedef struct{
	TEST_CMD cmd;
	uint16_t address;
	uint16_t value;
	char type; //register or frame
	uint8_t bits; //bits to check
}step;

step steps[1000];

uint16_t value1;

uint8_t readTagFound=0;
uint8_t writeTagFound=0;
uint8_t delayTagFound=0;
uint8_t addressTagFound=0;
uint8_t valueTagFound=0;
uint8_t typeTagFound=0;
uint8_t bitsTagFound=0;

uint8_t frameBits;
uint8_t regBits;

char tagData[20];

int Depth;
uint16_t step_idx=0;
enum XML_Status status;
char text[255];

uint8_t initSteps(char* buff){
	step_idx=0;
	XML_Parser parser=XML_ParserCreate(NULL);
	XML_SetUserData(parser, &Depth);
	XML_SetElementHandler(parser, start, end);
	XML_SetCharacterDataHandler(parser,characterDataHandler);
	status=XML_Parse(parser, buff, strlen(buff), 1);
	XML_ParserFree(parser);
	if (status!=XML_STATUS_OK){
		return 1;
	}
	else{
		return 0;
	}
}

//get called when an xml opening tag detected
     static void XMLCALL
     start(void *data, const XML_Char *el, const XML_Char **attr)
     {
       int i;
       (void)data;

       //el parameter contains the name of the xml tag
       if (strcmp(el,"read")==0){
    	   //readTagFound=1;
    	   steps[step_idx].cmd=CMD_READ;
       }
       if (strcmp(el,"write")==0){
    	   //writeTagFound=1;
    	   steps[step_idx].cmd=CMD_WRITE;
       }
       if (strcmp(el,"check")==0){
    	   steps[step_idx].cmd=CMD_CHECK;
       }
       if (strcmp(el,"delay")==0){
    	   delayTagFound=1;
       }
       if (strcmp(el,"address")==0){
		   addressTagFound=1;
       }
       if (strcmp(el,"value")==0){
    	   valueTagFound=1;
       }
       if (strcmp(el,"type")==0){
    	   typeTagFound=1;
       }
       if (strcmp(el,"bits")==0){
    	   bitsTagFound=1;
       }

       Depth++;
     }

     //get called when an xml closing tag detected
     static void XMLCALL
     end(void *data, const XML_Char *el)
     {
       (void)data;
       //(void)el;
       if (strcmp(el,"read")==0){
    	   step_idx++;
       }
       if (strcmp(el,"write")==0){
    	   step_idx++;
       }
       if (strcmp(el,"delay")==0){
    	   step_idx++;
       }
       if (strcmp(el,"check")==0){
    	   step_idx++;
       }
       Depth--;
     }


     static void XMLCALL
     characterDataHandler(void *data, const XML_Char *s, int len)
     {
       int i;
       (void)data;

       if (delayTagFound==1){
		   delayTagFound=0;
		   for (i=0; i<len; i++){
			   //s contains the value of the tag
			   //eg: <name>Peter</name>  ->  s="Peter"
			   tagData[i]=s[i];
		   }
		   tagData[len]='\0';
		   steps[step_idx].cmd=CMD_DELAY;
		   steps[step_idx].value=atoi(tagData);
       }
       if (addressTagFound==1){
		   addressTagFound=0;
		   for (i=0; i<len; i++){
			   tagData[i]=s[i];
		   }
		   tagData[len]='\0';

		   //value in binary format
		   if (len>5){
			   steps[step_idx].address=strtol(tagData,NULL,2);
		   }
		   //value in hex format
		   else{
			   steps[step_idx].address=strtol(tagData,NULL,16);
		   }
       }
       if (valueTagFound==1){
		   valueTagFound=0;
		   for (i=0; i<len; i++){
			   tagData[i]=s[i];
		   }
		   tagData[len]='\0';

		   //value in binary format
		   if (len>5){
			   steps[step_idx].value=strtol(tagData,NULL,2);
		   }
		   //value in hex format
		   else{
			   steps[step_idx].value=strtol(tagData,NULL,16);
		   }
       }
       if (typeTagFound==1){
    	   typeTagFound=0;
    	   for (i=0; i<len; i++){
    		   tagData[i]=s[i];
		   }
    	   tagData[len]='\0';
    	   if (strcmp(tagData,"frame")==0){
    		   steps[step_idx].type='f';
    	   }
    	   else if (strcmp(tagData,"reg")==0){
    		   steps[step_idx].type='r';
    	   }
       }
       if (bitsTagFound==1){
    	   bitsTagFound=0;
		   for (i=0; i<len; i++){
			   tagData[i]=s[i];
		   }
		   tagData[len]='\0';
		   steps[step_idx].bits=strtol(tagData,NULL,2);
       }
     }

// returns 1 if startup was not successful
// otherwise returns 0
uint8_t runTest(char* filename, uint8_t startup){
	uint16_t i,j;
	uint16_t addr;
	uint16_t value;

	uint16_t mask=0b01000000;
	uint8_t par;
	if (startup==1){
		sprintf(text,"\n\n####################################");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#            Start-up              #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n####################################");
		myLog(filename,text,0,2);
		for (i=0; i<step_idx; i++){
			switch (steps[i].cmd){
				case CMD_READ:
					value=readRegFULL(steps[i].address);
					sprintf(text,"\nread from address: 0x%02x",steps[i].address);
					myLog(filename,text,value,0);
					break;

				case CMD_WRITE:
					addr=steps[i].address;
					value=writeReg(steps[i].address,steps[i].value);
					sprintf(text,"\nwrite to address: 0x%02x, value: 0x%02x",steps[i].address,steps[i].value);
					myLog(filename,text,value,0);
					break;

				case CMD_DELAY:
					HAL_Delay(steps[i].value);
					sprintf(text,"\ndelay: %d ms",steps[i].value);
					myLog(filename,text,0,1);
					break;

				case CMD_CHECK:
					if (steps[i].type=='f'){
						mask=0b01000000;
						frameBits=(value & 0xFF00) >> 8;
						for (j=0; j<6; j++){
							if ((steps[i].bits & mask)!=0){
								if ((frameBits & mask)!=(steps[i].value & mask)){
									sprintf(text,"\n  Error in SPI frame bits!");
									myLog(filename,text,value,0);
									sprintf(text,"\n  Star-Up sequence stopped!");
									myLog(filename,text,value,0);
									return 1;
								}
							}
							mask >>= 1;
						}
						//check parity
						if ((steps[i].bits & mask)!=0){
							par=calculateOddParity(value & 0x00FF);
							if (par != (frameBits & mask)){
								sprintf(text,"\n  Parity Error!");
								myLog(filename,text,value,0);
								sprintf(text,"\n  Star-Up sequence stopped!");
								myLog(filename,text,value,0);
								return 1;
							}
						}
					}
					else if(steps[i].type=='r'){
						mask=0b100000000;
						regBits=value & 0x00FF;
						for (j=0; j<8; j++){
							if ((steps[i].bits & mask)!=0){
								if ((regBits & mask)!=(steps[i].value & mask)){
									sprintf(text,"\n  Error in register bits!");
									myLog(filename,text,value,0);
									sprintf(text,"\n  Star-Up sequence stopped!");
									myLog(filename,text,value,0);
									return 1;
								}
							}
							mask >>= 1;
						}
					}
					break;
			}
		}
		sprintf(text,"\n\n####################################");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#          End of Start-up         #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n####################################");
		myLog(filename,text,0,2);
	}
	else{
		sprintf(text,"\n\n####################################");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#          Test sequence           #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n####################################");
		myLog(filename,text,0,2);
		for (i=0; i<step_idx; i++){
			switch (steps[i].cmd){
				case CMD_READ:
					value=readRegFULL(steps[i].address);
					sprintf(text,"\nread from address: 0x%02x",steps[i].address);
					myLog(filename,text,value,0);
					break;

				case CMD_WRITE:
					addr=steps[i].address;
					value1=writeReg(steps[i].address,steps[i].value);
					//value1=writeReg(steps[i].address,steps[i].value);
					sprintf(text,"\nwrite to address: 0x%02x, value: 0x%02x",steps[i].address,steps[i].value);
					myLog(filename,text,value,0);
					break;

				case CMD_DELAY:
					HAL_Delay(steps[i].value);
					sprintf(text,"\ndelay: %d ms",steps[i].value);
					myLog(filename,text,0,1);
					break;
			}
		}
		sprintf(text,"\n\n####################################");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#       End of Test sequence       #");
		myLog(filename,text,0,2);
		sprintf(text,"\n#                                  #");
		myLog(filename,text,0,2);
		sprintf(text,"\n####################################");
		myLog(filename,text,0,2);
	}
	return 0;
}
