#include "myLog.h"


void myLog(char* filename, char* text, uint16_t value, uint8_t type){
	char tempstr[500];
	char statusBits[8];
	char datastr[10];
	char datastr2[10];
	uint8_t i;

	// log register read or write
	if (type==0){
		uint16_t mask=0b0100000000000000;
		for (i=0; i<7; i++){
			if ((value & mask) > 0){
			  statusBits[i]='1';
			}
			else{
			  statusBits[i]='0';
			}
			mask >>= 1;
		}
		statusBits[7]='\0';
		sprintf(datastr,"0x%02x",(value & 0x00FF));
		mask=0b0000000010000000;
		for (i=0; i<8; i++){
			if ((value & mask) > 0){
				datastr2[i]='1';
			}
			else{
				datastr2[i]='0';
			}
			mask >>= 1;
		}
		datastr2[8]='\0';
		sprintf(tempstr,"\nFRME | PORST | ST | SAT | 0 | 1 | dPAR | data (bin) | data (hex)\n  %c  |   %c   | %c  |  %c  | %c | %c |   %c  |  %s  |    %s\n",statusBits[0],statusBits[1],statusBits[2],statusBits[3],statusBits[4],statusBits[5],statusBits[6],datastr2,datastr);
		writeToSDAppend(filename,text,strlen(text));
		writeToSDAppend(filename,tempstr,strlen(tempstr));
		writeToSDAppend(filename,"\n--------------------------------------------------",51);
	}
	//log delay
	else if (type==1){
		writeToSDAppend(filename,text,strlen(text));
		writeToSDAppend(filename,"\n--------------------------------------------------",51);
	}
	//write custom text to file
	else{
		writeToSDAppend(filename,text,strlen(text));
	}
}
