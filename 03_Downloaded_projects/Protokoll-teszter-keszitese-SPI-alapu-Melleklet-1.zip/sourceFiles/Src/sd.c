#include "sd.h";



FATFS SDFatFs;  /* File system object for SD card logical drive */
FIL MyFile;     /* File object */
DIR dir;
FILINFO finfo;
char SDPath[4]; /* SD card logical drive path */

FRESULT res;    /* FatFs function common result code */
uint32_t byteswritten, bytesread;

FRESULT mount(){
	if(FATFS_LinkDriver(&SD_Driver, SDPath) == 0){
	   /*##-2- Register the file system object to the FatFs module ##############*/
		res=f_mount(&SDFatFs, (TCHAR const*)SDPath, 1);
	}
	return res;
}

FRESULT readFromSD(char* filename, char* buff, uint16_t size){
	res=f_open(&MyFile, filename, FA_READ);
	if (res!=FR_OK){
		return res;
	}
	res = f_read(&MyFile, buff, size, (UINT*)&bytesread);
	if((bytesread == 0) || (res != FR_OK))
	{
	 f_close(&MyFile);
	 return res;
	}
	buff[bytesread]='\0';
	f_close(&MyFile);
	return res;
}

FRESULT writeToSD(char* filename, char* buff, uint16_t size){
	res=f_open(&MyFile, filename, FA_CREATE_ALWAYS | FA_WRITE);
	if (res!=FR_OK){
		return res;
	}
	res = f_write(&MyFile, buff, size, (UINT*)&byteswritten);
	if((byteswritten == 0) || (res != FR_OK))
	{
		f_close(&MyFile);
		return res;
	}
	f_close(&MyFile);
	return res;
}

FRESULT writeToSDAppend(char* filename, char*buff, uint16_t size){
	res=f_open(&MyFile, filename, FA_OPEN_ALWAYS | FA_WRITE);
	if (res!=FR_OK){
		return res;
	}
	res=f_lseek(&MyFile,f_size(&MyFile));
	res = f_write(&MyFile, buff, size, (UINT*)&byteswritten);
	if((byteswritten == 0) || (res != FR_OK))
	{
		f_close(&MyFile);
		return res;
	}
	f_close(&MyFile);
	return res;
}

FRESULT checkFile(char* filename){
	res=f_open(&MyFile, filename, FA_READ);
	f_close(&MyFile);
	return res;
}

FRESULT createEmptyFile(char* filename){
	res=f_open(&MyFile, filename, FA_CREATE_ALWAYS);
	f_close(&MyFile);
	return res;
}

uint8_t getFiles(uint8_t n, uint8_t m, char fnames[n][m]){
	uint8_t i=0, j=0, fCount=0;
	res = f_opendir(&dir, SDPath);
	if (res == FR_OK) {
		res=f_readdir(&dir, &finfo);
		if (res== FR_OK){
			while (finfo.fname[0]!=0){
				for (i=0; i<strlen(finfo.fname);i++){
					fnames[j][i]=finfo.fname[i];
				}
				fnames[j][strlen(finfo.fname)]='\0';
				res=f_readdir(&dir, &finfo);
				j++;
				fCount++;
			}
		}
	}
	return fCount;
}
