# stm32f7_scope
Simple scope for STM32F7 Discovery board

This repository cotains all project files for SW4STM32 IDE. It can be imported using "File->Import->Existing Projects into Workspace" option.
