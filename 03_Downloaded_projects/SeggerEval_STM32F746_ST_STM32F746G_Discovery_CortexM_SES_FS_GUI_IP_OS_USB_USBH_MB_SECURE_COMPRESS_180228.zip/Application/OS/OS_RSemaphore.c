/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : OS_RSemaphore.c
Purpose : embOS sample program for resource semaphore.
--------  END-OF-HEADER  ---------------------------------------------
*/

#include "RTOS.h"
#include "stdio.h"

static OS_STACKPTR int StackHP[128];   /* Task stacks */
static OS_TASK         TCBHP;          /* Task-control-blocks */
static OS_RSEMA        RSema;

/*********************************************************************
*
*       _Write()
*/
static void _Write(char const* s) {
  OS_Use(&RSema);
  printf(s);
  OS_Unuse(&RSema);
}

/*********************************************************************
*
*       HPTask()
*/
static void HPTask(void) {
  while (1) {
    _Write("HPTask\n");
    OS_Delay(50);
  }
}

/*********************************************************************
*
*       main()
*/

/*********************************************************************
*
*       MainTask()
*/
#ifdef __cplusplus
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif
void MainTask(void);
#ifdef __cplusplus
}
#endif
void MainTask(void) {
  OS_CreateRSema(&RSema);  /* Creates resource semaphore    */
  OS_CREATETASK(&TCBHP, "HP Task", HPTask, 100, StackHP);
  while (1) {
    _Write("MainTask\n");
    OS_Delay(200);
  }  
}

/****** End Of File *************************************************/
