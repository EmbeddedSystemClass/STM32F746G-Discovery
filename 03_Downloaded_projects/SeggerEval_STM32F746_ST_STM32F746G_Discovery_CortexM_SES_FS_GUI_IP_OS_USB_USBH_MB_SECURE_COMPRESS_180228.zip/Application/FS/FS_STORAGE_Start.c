/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
-------------------------- END-OF-HEADER -----------------------------

File    : FS_STORAGE_Start.c
Purpose : Start application for the storage layer of the file system.
*/

/*********************************************************************
*
*       #include Section
*
**********************************************************************
*/
#include <stdio.h>
#include <string.h>
#include "FS.h"

/*********************************************************************
*
*       Defines, configurable
*
**********************************************************************
*/
#define VOLUME_NAME         ""
#define MAX_SECTOR_SIZE     2048
#define SECTOR_INDEX        0

/*********************************************************************
*
*       Static data
*
**********************************************************************
*/
static U32  _aBuffer[MAX_SECTOR_SIZE / 4];
static char _ac[256];

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/

/*********************************************************************
*
*       MainTask
*/
#ifdef __cplusplus
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif
void MainTask(void);
#ifdef __cplusplus
}
#endif
void MainTask(void) {
  int           r;
  FS_DEV_INFO   DevInfo;
  U32         * pData32;
  U32           Cnt;
  U32           NumLoops;
  U32           BytesPerSector;

  FS_X_Log("Start\n");
  //
  // Initialize file system.
  //
  FS_STORAGE_Init();
  //
  // Perform a low-level format if required.
  //
  if (FS_IsLLFormatted(VOLUME_NAME) == 0) {
    r = FS_FormatLow(VOLUME_NAME);
    if (r < 0) {
      FS_X_Log("Low-level format failed.\n");
      goto Done;
    }
    FS_X_Log("Low-level format\n");
  }
  //
  // Get and show information about the storage device.
  //
  memset(&DevInfo, 0, sizeof(DevInfo));
  r = FS_STORAGE_GetDeviceInfo(VOLUME_NAME, &DevInfo);
  if (r) {
    FS_X_Log("Could not get device info.\n");
    goto Done;
  }
  BytesPerSector = DevInfo.BytesPerSector;
  FS_X_Log("Device info:\n");
  sprintf(_ac, "  Volume name:       \"%s\"\n",    VOLUME_NAME);
  FS_X_Log(_ac);
  sprintf(_ac, "  Number of sectors: %lu\n",       DevInfo.NumSectors);
  FS_X_Log(_ac);
  sprintf(_ac, "  Sector size:       %lu bytes\n", BytesPerSector);
  FS_X_Log(_ac);
  //
  // Check if the sector buffer is large enough.
  //
  if (BytesPerSector > sizeof(_aBuffer)) {
    FS_X_Log("Sector buffer too small.\n");
    goto Done;
  }
  //
  // Write some data to a sector, read it back and verify it.
  //
  sprintf(_ac, "Write, read and verify sector %lu\n", (long unsigned)SECTOR_INDEX);
  FS_X_Log(_ac);
  NumLoops = DevInfo.BytesPerSector >> 2;
  pData32  = _aBuffer;
  Cnt      = 0;
  do {
    *pData32++ = Cnt++;
  } while (--NumLoops);
  r = FS_STORAGE_WriteSector(VOLUME_NAME, _aBuffer, SECTOR_INDEX);
  if (r) {
    FS_X_Log("Could not write sector data.\n");
    goto Done;
  }
  r = FS_STORAGE_ReadSector(VOLUME_NAME, _aBuffer, SECTOR_INDEX);
  if (r) {
    FS_X_Log("Could not read sector data.\n");
    goto Done;
  }
  NumLoops = DevInfo.BytesPerSector >> 2;
  pData32  = _aBuffer;
  Cnt      = 0;
  do {
    if (*pData32++ != Cnt++) {
      FS_X_Log("Verification failed.\n");
      break;
    }
  } while (--NumLoops);
Done:
  FS_STORAGE_Unmount(VOLUME_NAME);
  FS_X_Log("Finished\n");
  while (1) {
    ;
  }
}

/*************************** End of file ****************************/
