/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File        : COMPRESS_Int.h
Purpose     : Internal aspects of emCompress.
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef COMPRESS_INT_H
#define COMPRESS_INT_H

#include "SEGGER.h"
#include "SEGGER_MEM.h"
#include "COMPRESS.h"

#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************
*
*       Defines, fixed.
*
**********************************************************************
*/

#ifndef COMPRESS_TRIAL
  #define COMPRESS_TRIAL 0
#endif
#if COMPRESS_TRIAL > 0
  #define TRIAL_LIMIT 0x4000
#endif

/*********************************************************************
*
*       Compressor action requested of client.
*/
#define COMPRESS_RESULT_OUTPUT      1   // Empty output buffers, make more space.
#define COMPRESS_RESULT_INPUT       2   // Provide additional input.
#define COMPRESS_RESULT_DONE        3   // Encode or decode complete.
#define COMPRESS_GENERAL_ERROR   -100   // Error in function call sequence.
#define COMPRESS_OUT_OF_MEMORY   -101   // Allocation failed
#define COMPRESS_BITSTREAM_ERROR -102   // Bitstream is invalid
#define COMPRESS_PARAMETER_ERROR -103   // Error in function call sequence.
#define COMPRESS_CRC_ERROR       -104   // CRC check failed.

//
// LZSS control codes.
//
#define COMPRESS_LZSS_EOF                       0x100

//
// LZW stream control codes.
//
#define COMPRESS_LZW_END_OF_STREAM              256
#define COMPRESS_LZW_BUMP_CODE                  257
#define COMPRESS_LZW_FLUSH_CODE                 258
#define COMPRESS_LZW_FIRST_CODE                 259  // First code for compressed data.

//
// Macros for exceptions and exception handling.
//
#define COMPRESS_ALLOC(LVALUE, ALLOC, SIZE)      do { if (((LVALUE) = SEGGER_MEM_Alloc((ALLOC), (SIZE))) == 0)     { Status = COMPRESS_OUT_OF_MEMORY; goto cleanup; } } while (0)
#define COMPRESS_ZEROALLOC(LVALUE, ALLOC, SIZE)  do { if (((LVALUE) = SEGGER_MEM_ZeroAlloc((ALLOC), (SIZE))) == 0) { Status = COMPRESS_OUT_OF_MEMORY; goto cleanup; } } while (0)
#define COMPRESS_CHECK_ALLOC(X)                  do { if ((X) == 0)                              { (void)SSL_LOG_ERR(SSL_OUT_OF_MEMORY); Status = SSL_OUT_OF_MEMORY; goto cleanup; } } while (0)
#define COMPRESS_RETURN(X)                       do { Status = X; goto cleanup; } while (0)
#define COMPRESS_CHECK(X)                        do { Status = X; if (Status < 0) goto cleanup; } while (0)

/*********************************************************************
*
*       Bit-level I/O interface.
*/
typedef struct {
  U8   BitNum;
  U8   Data;
  U8 * pByteBuffer;
  U32  ByteBufferCount;
  U32  ByteBufferSize;
} COMPRESS_BITIO_CONTEXT;


/*********************************************************************
*
*       Forward structures.
*/
typedef struct COMPRESS_ENCODE_CONTEXT COMPRESS_ENCODE_CONTEXT;
typedef struct COMPRESS_DECODE_CONTEXT COMPRESS_DECODE_CONTEXT;

/*********************************************************************
*
*       Encoder-Decoder (codec) API.
*/

typedef struct {
  void  (*pfCopyName) (char *pBuf);
  int   (*pfInit)     (COMPRESS_ENCODE_CONTEXT *pSelf, COMPRESS_PARA aPara[]);
  void  (*pfExit)     (COMPRESS_ENCODE_CONTEXT *pSelf);
  int   (*pfEncode)   (COMPRESS_ENCODE_CONTEXT *pSelf, int Flush);
} COMPRESS_ENCODE_API;

struct COMPRESS_DECODE_API_tag {
  void  (*pfCopyName) (char *pBuf);
  int   (*pfInit)     (COMPRESS_DECODE_CONTEXT *pSelf, COMPRESS_PARA aPara[]);
  void  (*pfExit)     (COMPRESS_DECODE_CONTEXT *pSelf);
  int   (*pfDecode)   (COMPRESS_DECODE_CONTEXT *pSelf, int Flush);
};

struct COMPRESS_ENCODE_CONTEXT {
  void                      * pWork;
  const COMPRESS_ENCODE_API * pAPI;
  SEGGER_MEM_CONTEXT        * pMem;
  const U8                  * pInput;
  U32                         InputByteCnt;
  COMPRESS_BITIO_CONTEXT      Output;
};

struct COMPRESS_DECODE_CONTEXT {
  void                      * pWork;
  const COMPRESS_DECODE_API * pAPI;
  SEGGER_MEM_CONTEXT        * pMem;
  U8                        * pOutput;
  U32                         OutputByteCnt;
  U32                         OutputSize;
  COMPRESS_BITIO_CONTEXT      Input;
};

/*********************************************************************
*
*       Forward types.
*
**********************************************************************
*/

struct COMPRESS_ENCODE_CONTEXT;
struct COMPRESS_DECODE_CONTEXT;

/*********************************************************************
*
*       Public const data
*
**********************************************************************
*/

extern const U8 COMPRESS_DEFLATE__aCodeLengthCodeOrder[19];

/*********************************************************************
*
*       Internal functions
*
**********************************************************************
*/

/*********************************************************************
*
*       Informational functions.
*/
void     COMPRESS_ENCODE_CopyName                    (const COMPRESS_ENCODE_API *pAPI, char *sText);
void     COMPRESS_DECODE_CopyName                    (const COMPRESS_DECODE_API *pAPI, char *sText);

/*********************************************************************
*
*       Encoder functions.
*/
int      COMPRESS_ENCODE_Init                        (COMPRESS_ENCODE_CONTEXT *pSelf, const COMPRESS_ENCODE_API *pAPI, SEGGER_MEM_CONTEXT *pMem, COMPRESS_PARA aPara[]);
void     COMPRESS_ENCODE_Exit                        (COMPRESS_ENCODE_CONTEXT *pSelf);
int      COMPRESS_ENCODE_Run                         (COMPRESS_ENCODE_CONTEXT *pSelf, int Flush);

/*********************************************************************
*
*       Decoder functions.
*/
int      COMPRESS_DECODE_Init                        (COMPRESS_DECODE_CONTEXT *pSelf, const COMPRESS_DECODE_API *pAPI, SEGGER_MEM_CONTEXT *pMem, COMPRESS_PARA aPara[]);
void     COMPRESS_DECODE_Exit                        (COMPRESS_DECODE_CONTEXT *pSelf);
int      COMPRESS_DECODE_Run                         (COMPRESS_DECODE_CONTEXT *pSelf, int Flush);

/*********************************************************************
*
*       Utility functions.
*/
int  COMPRESS__BitCount            (unsigned Value);
U32      COMPRESS__BitReverse                        (U32 Value, unsigned Length);
int  COMPRESS__CircularCompare     (const U8 *pWindow, unsigned I0, unsigned I1, unsigned Length, unsigned Wrap);

/*********************************************************************
*
*       Core Start-Step-Stop codec.
*/
void     COMPRESS_SSS_Encode                         (COMPRESS_BITIO_CONTEXT *pIO, unsigned Start, unsigned Step, unsigned Stop, unsigned Data);
U32      COMPRESS_SSS_Decode                         (COMPRESS_BITIO_CONTEXT *pIO, unsigned Start, unsigned Step, unsigned Stop);

/*********************************************************************
*
*       Instances of the Start-Step-Stop codec.  Used by LZJU90.
*/
void     COMPRESS_SSS_Encode_0_1_7                   (COMPRESS_BITIO_CONTEXT *pIO, unsigned Data);
U32      COMPRESS_SSS_Decode_0_1_7                   (COMPRESS_BITIO_CONTEXT *pIO);
void     COMPRESS_SSS_Encode_9_1_14                  (COMPRESS_BITIO_CONTEXT *pIO, unsigned Data);
U32      COMPRESS_SSS_Decode_9_1_14                  (COMPRESS_BITIO_CONTEXT *pIO);

/*********************************************************************
*
*       Bit-level I/O interface.
*/
void     COMPRESS_BITIO_Init                         (COMPRESS_BITIO_CONTEXT *pSelf);
void     COMPRESS_BITIO_Exit                         (COMPRESS_BITIO_CONTEXT *pSelf);
void     COMPRESS_BITIO_WrBit                        (COMPRESS_BITIO_CONTEXT *pSelf, unsigned Data);
void     COMPRESS_BITIO_WrLSBFirst                   (COMPRESS_BITIO_CONTEXT *pSelf, U32 Data, unsigned Length);
void     COMPRESS_BITIO_WrMSBFirst                   (COMPRESS_BITIO_CONTEXT *pSelf, U32 Data, unsigned Length);
int  COMPRESS_BITIO_RdBit          (COMPRESS_BITIO_CONTEXT *pSelf);
U32      COMPRESS_BITIO_RdLSBFirst                   (COMPRESS_BITIO_CONTEXT *pSelf, unsigned Length);
U32      COMPRESS_BITIO_RdMSBFirst                   (COMPRESS_BITIO_CONTEXT *pSelf, unsigned Length);
void     COMPRESS_BITIO_Align                        (COMPRESS_BITIO_CONTEXT *pSelf, unsigned Fill);
void     COMPRESS_BITIO_Rewind                       (COMPRESS_BITIO_CONTEXT *pSelf, unsigned Bits);

/*********************************************************************
*
*       Codec default substitution.
*/
int      COMPRESS_RLE__SubstituteDefaults            (COMPRESS_PARA aPara[]);
int      COMPRESS_HUFF__SubstituteDefaults           (COMPRESS_PARA aPara[]);
int      COMPRESS_LZSS__SubstituteDefaults           (COMPRESS_PARA aPara[]);
int      COMPRESS_LZJU90__SubstituteDefaults         (COMPRESS_PARA aPara[]);
int      COMPRESS_DEFLATE__SubstituteDefaults        (COMPRESS_PARA aPara[]);

/*********************************************************************
*
*       Public const data
*
**********************************************************************
*/

/*********************************************************************
*
*       RLE codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_RLE_Encode;
extern const COMPRESS_DECODE_API COMPRESS_RLE_Decode;

/*********************************************************************
*
*       LZSS codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_LZSS_Encode;
extern const COMPRESS_DECODE_API COMPRESS_LZSS_Decode;

/*********************************************************************
*
*       LZJU90 codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_LZJU90_Encode;
extern const COMPRESS_DECODE_API COMPRESS_LZJU90_Decode;

/*********************************************************************
*
*       LZW dynamic codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_LZW_Encode;
extern const COMPRESS_DECODE_API COMPRESS_LZW_Decode;

/*********************************************************************
*
*       DEFLATE codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_DEFLATE_Encode;
extern const COMPRESS_DECODE_API COMPRESS_DEFLATE_Decode;

/*********************************************************************
*
*       Huffman codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_HUFF_Encode;
extern const COMPRESS_DECODE_API COMPRESS_HUFF_Decode;

/*********************************************************************
*
*       STORE codecs.
*/
extern const COMPRESS_ENCODE_API COMPRESS_STORE_Encode;
extern const COMPRESS_DECODE_API COMPRESS_STORE_Decode;

#ifdef __cplusplus
}
#endif

#endif

/****** End Of File *************************************************/
