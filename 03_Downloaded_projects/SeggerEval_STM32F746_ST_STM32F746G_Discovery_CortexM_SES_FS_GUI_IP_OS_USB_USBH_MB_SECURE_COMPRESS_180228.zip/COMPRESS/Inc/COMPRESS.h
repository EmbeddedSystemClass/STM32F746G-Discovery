/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File        : COMPRESS.h
Purpose     : SEGGER Compression Library User-Level API.
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef COMPRESS_H
#define COMPRESS_H

/*********************************************************************
*
*       #include Section
*
**********************************************************************
*/

#include "COMPRESS_ConfDefaults.h"

#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************
*
*       Defines, fixed.
*
**********************************************************************
*/

#define COMPRESS_VERSION        21200

/*********************************************************************
*
*       Types required for API
*
**********************************************************************
*/

typedef int (*COMPRESS_OUTPUT_FUNC)(void *pContext, void *pData, unsigned NumBytes);
typedef U32 (*COMPRESS_CRC_FUNC)   (const U8 *pData, U32 NumBytes, U32 CRC);
typedef U32 COMPRESS_PARA;

typedef struct COMPRESS_DECODE_API_tag COMPRESS_DECODE_API;

typedef struct {
  const U8 * pData;
  U32        NumBytesData;
} COMPRESS_ENCODED_DATA;

typedef struct {
  const U8                  * pEncodedData;       // Compressed bitstream
  U32                         EncodedDataLength;  // Compressed image size
  U32                         EncodedDataCRC;     // Compressed image CRC
  const COMPRESS_DECODE_API * pDecoder;           // Decoder for compressed bitstream
  U32                         DecodedDataStart;   // Start of slice within original image
  U32                         DecodedDataLength;  // Size of slice within original image
  U32                         DecodedDataCRC;     // CRC over original input slice
  U32                         WorkspaceSize;      // Number of bytes required for workspace on decompression
  COMPRESS_PARA               aPara[3];
} COMPRESS_ENCODED_FILE;

/*********************************************************************
*
*       API functions
*
**********************************************************************
*/

/*********************************************************************
*
*       All-in-one packaged API.
*/
int  COMPRESS_DecompressThruFunc   (const COMPRESS_ENCODED_FILE *pSelf, void *pWorkspace, unsigned NumBytesWorkspace, COMPRESS_OUTPUT_FUNC pfOutput, void *pContext, U32 Start, U32 Len, COMPRESS_CRC_FUNC pfCalcCRC);
int  COMPRESS_DecompressToMem      (const COMPRESS_ENCODED_FILE *pSelf, void *pWorkspace, unsigned NumBytesWorkspace, void *pDest,                                   U32 Start, U32 Len, COMPRESS_CRC_FUNC pfCalcCRC);

/*********************************************************************
*
*       Inquiries.
*/
void COMPRESS_QueryEncodedData     (const COMPRESS_ENCODED_FILE *pSelf, COMPRESS_ENCODED_DATA *pData);
U32  COMPRESS_QueryEncodedDataSize (const COMPRESS_ENCODED_FILE *pSelf);
U32  COMPRESS_QueryEncodedDataCRC  (const COMPRESS_ENCODED_FILE *pSelf);
U32  COMPRESS_QueryDecodedDataSize (const COMPRESS_ENCODED_FILE *pSelf);
U32  COMPRESS_QueryDecodedDataCRC  (const COMPRESS_ENCODED_FILE *pSelf);
U32  COMPRESS_QueryWorkspaceSize   (const COMPRESS_ENCODED_FILE *pSelf);

/*********************************************************************
*
*       Failure handling functions.
*/
void COMPRESS_AssertFail           (const char *sFilename, int LineNumber, const char *sAssertion);

#ifdef __cplusplus
}
#endif

#endif

/****** End Of File *************************************************/
