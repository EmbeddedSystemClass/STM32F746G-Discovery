/*********************************************************************
*                     SEGGER Microcontroller GmbH                    *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 1995 - 2018 SEGGER Microcontroller GmbH                  *
*                                                                    *
*       Internet: segger.com  Support: support_embos@segger.com      *
*                                                                    *
**********************************************************************
*                                                                    *
*       embOS * Real time operating system for microcontrollers      *
*                                                                    *
*       Please note:                                                 *
*                                                                    *
*       Knowledge of this file may under no circumstances            *
*       be used to write a similar product or a real-time            *
*       operating system for in-house use.                           *
*                                                                    *
*       Thank you for your fairness !                                *
*                                                                    *
**********************************************************************
*                                                                    *
*       OS version: 4.40                                             *
*                                                                    *
**********************************************************************

----------------------------------------------------------------------
File    : embOSPluginSES.js
Purpose : Script for thread windows for embOS and SEGGER Embedded Studio
--------  END-OF-HEADER  ---------------------------------------------
*/

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/

/**** ARM Register indices, constant ********************************/
var arm_r0  =  0;
var arm_r1  =  1;
var arm_r2  =  2;
var arm_r3  =  3;
var arm_r4  =  4;
var arm_r5  =  5;
var arm_r6  =  6;
var arm_r7  =  7;
var arm_r8  =  8;
var arm_r9  =  9;
var arm_r10 = 10;
var arm_r11 = 11;
var arm_r12 = 12;
var arm_sp  = 13;
var arm_lr  = 14;
var arm_pc  = 15;
var arm_psr = 16;

//
// embOS preserves an additional [pseudo] register
// (exec location with ARM and a modified LR with Cortex-M)
//
var arm_exec = 15;

/**** RISC-V Register indices, constant ********************************/
var riscv_pc  =  0;
var riscv_ra  =  1;
var riscv_sp  =  2;
var riscv_gp  =  3;
var riscv_tp  =  4;
var riscv_t0  =  5;
var riscv_t1  =  6;
var riscv_t2  =  7;
var riscv_s0  =  8;
var riscv_s1  =  9;
var riscv_a0  = 10;
var riscv_a1  = 11;
var riscv_a2  = 12;
var riscv_a3  = 13;
var riscv_a4  = 14;
var riscv_a5  = 15;
var riscv_a6  = 16;
var riscv_a7  = 17;
var riscv_s2  = 18;
var riscv_s3  = 19;
var riscv_s4  = 20;
var riscv_s5  = 21;
var riscv_s6  = 22;
var riscv_s7  = 23;
var riscv_s8  = 24;
var riscv_s9  = 25;
var riscv_s10 = 26;
var riscv_s11 = 27;
var riscv_t3  = 28;
var riscv_t4  = 29;
var riscv_t5  = 30;
var riscv_t6  = 31;

/**** embOS task states, constant ***********************************/
var TS_READY            = (0x00 << 3);  // ready
var TS_WAIT_EVENT       = (0x01 << 3);  // waiting for task event
var TS_WAIT_SEMAZ       = (0x02 << 3);  // waiting for resource semaphore
var TS_WAIT_ANY         = (0x03 << 3);  // Waiting for any reason
var TS_WAIT_SEMANZ      = (0x04 << 3);  // Waiting for counting semaphore
var TS_WAIT_MEMF        = (0x05 << 3);  // Waiting for memory pool since V4.30
var TS_WAIT_MEMF_old    = (0x05 << 5);  // Waiting for memory pool pre V4.30
var TS_WAIT_QNE         = (0x06 << 3);  // Waiting for message in queue
var TS_WAIT_MBNF        = (0x07 << 3);  // Waiting for space in mailbox
var TS_WAIT_MBNE        = (0x08 << 3);  // Waiting for message in mailbox
var TS_WAIT_EVENTOBJ    = (0x09 << 3);  // Waiting for event object
var TS_WAIT_QNF         = (0x0A << 3);  // Waiting for space in queue

var TS_MASK_SUSPEND_CNT = (0x03 << 0);  // Mask for task suspension count
var TS_MASK_TIMEOUT     = (0x01 << 2);  // Mask for task timeout period
var TS_MASK_STATE       = (0xF8 << 0);  // Mask for task state

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/

/*********************************************************************
*
*       getregs()
*
*  Functions description:
*    If a thread is selected in the threads window, this function returns
*    an array containing the registers r0-r12, sp, lr, pc, and psr.
*
*  Parameters
*    x: Pointer to task control block
*/
function getregs(x) {
  if (Debug.evaluate("SkipSaveMainContextRISCV")) {  // This is for embOS for RISCV
    var aRegs       = new Array(32);
    var Interrupted = 0;
    var PreviousPC;
    var VectoredMode;

    aRegs[riscv_sp]   = Debug.evaluate("((OS_TASK*)" + x + ")->pStack");
    aRegs[riscv_sp]  += 4;  // "pop" Counters
    aRegs[riscv_s0]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s0
    aRegs[riscv_s1]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s1
    aRegs[riscv_s2]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s2
    aRegs[riscv_s3]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s3
    aRegs[riscv_s4]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s4
    aRegs[riscv_s5]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s5
    aRegs[riscv_s6]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s6
    aRegs[riscv_s7]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s7
    aRegs[riscv_s8]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s8
    aRegs[riscv_s9]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s9
    aRegs[riscv_s10]  = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s10
    aRegs[riscv_s11]  = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" s11
    aRegs[riscv_pc]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_ra]   = TargetInterface.peekWord(aRegs[riscv_sp]);
    aRegs[riscv_sp]  += 4;  // "pop" new pc / previous ra
    aRegs[riscv_sp]  += 8;  // "pop" alignment

    VectoredMode = Debug.evaluate("vtrap_entry");
    if (VectoredMode != NULL) {
      //
      // We've found vtrap_entry, thus are in vectored mode.
      //
      var OS_ISR_Local15;

      PreviousPC     = TargetInterface.peekWord(aRegs[riscv_sp] + 28);
      OS_ISR_Local15 = Debug.evaluate("OS_ISR_Local15");
      if ((PreviousPC >= VectoredMode) && (PreviousPC <= OS_ISR_Local15)) {
        Interrupted = 1;
      }
      VectoredMode = 1;
    } else {
      //
      // We haven't found vtrap_entry, thus are in direct mode.
      //
      var trap_entry;

      PreviousPC = TargetInterface.peekWord(aRegs[riscv_sp] + 60);
      trap_entry = Debug.evaluate("trap_entry");
      if ((PreviousPC >= trap_entry) && (PreviousPC <= trap_entry + 50)) {
        Interrupted = 1;
      }
      VectoredMode = 0;
    }

    if ((Interrupted == 1) && (VectoredMode == 1)){
      //
      // Task has been interrupted in vectored mode. Unstack exception frame and restore task register
      //
      aRegs[riscv_sp] += 32;  // "pop" high-level exception frame
      aRegs[riscv_ra]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" ra
      aRegs[riscv_t0]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t0
      aRegs[riscv_t1]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t1
      aRegs[riscv_t2]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t2
      aRegs[riscv_a0]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a0
      aRegs[riscv_a1]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a1
      aRegs[riscv_a2]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a2
      aRegs[riscv_a3]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a3
      aRegs[riscv_a4]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a4
      aRegs[riscv_a5]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a5
      aRegs[riscv_a6]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a6
      aRegs[riscv_a7]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" a7
      aRegs[riscv_t3]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t3
      aRegs[riscv_t4]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t4
      aRegs[riscv_t5]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t5
      aRegs[riscv_t6]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 4;  // "pop" t6
      //
      // Since we've been interrupted, using ra would result in an erroneous stack frame. Use mepc instead!
      //
      aRegs[riscv_pc]  = TargetInterface.peekWord(aRegs[riscv_sp]);
      aRegs[riscv_sp] += 16;  // Drop remaining stack frame, so the debugger can take care of any subsequent function parameters
    } else if ((Interrupted == 1) && (VectoredMode == 0)) {
      aRegs[riscv_sp] += 32;  // "pop" high-level exception frame
      aRegs[riscv_pc]  = TargetInterface.peekWord(aRegs[riscv_sp] + 8);
      aRegs[riscv_ra]  = TargetInterface.peekWord(aRegs[riscv_sp] + 32);
      aRegs[riscv_sp] += 36;  // Drop remaining stack frame, so the debugger can take care of any subsequent function parameters
    } else {
      aRegs[riscv_ra]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t0]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t1]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t2]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a0]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a1]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a2]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a3]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a4]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a5]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a6]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_a7]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t3]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t4]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t5]  = "0x00000000";  // unknown after cooperative task switch
      aRegs[riscv_t6]  = "0x00000000";  // unknown after cooperative task switch
    }
    //
    // Return default values for global pointer and thread pointer
    //
    aRegs[riscv_gp] = "0x00000000";  // unknown, this is never modified and is therefore not preserved
    aRegs[riscv_tp] = "0x00000000";  // unknown, this is never modified and is therefore not preserved

    return aRegs;
  } else {
    var aRegs       = new Array(17);
    var Interrupted = 0;
    var FPU_Used    = 0;
    var OSSwitch;
    var MPU_Used;

    MPU_Used = Debug.evaluate("(unsigned int*)(*(OS_TASK*)" + x + ").MPU_Config");
    MPU_Used = (MPU_Used != NULL) ? 1 : 0;

    //
    // Retrieve current top-of-stack
    //
    aRegs[arm_sp] = Debug.evaluate("((OS_TASK*)" + x + ")->pStack");
    //
    // Handle well known registers
    //
    aRegs[arm_sp]   += 4;  // "pop" Counters
    aRegs[arm_r4]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R4
    aRegs[arm_r5]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R5
    aRegs[arm_r6]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R6
    aRegs[arm_r7]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R7
    aRegs[arm_r8]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R8
    aRegs[arm_r9]    = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R9
    aRegs[arm_r10]   = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R10
    aRegs[arm_r11]   = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" R11
    if (MPU_Used != 0) {
      aRegs[arm_sp] += 8;  // "pop" CONTROL & Dummy
    }
    aRegs[arm_exec]  = TargetInterface.peekWord(aRegs[arm_sp]);
    aRegs[arm_sp]   += 4;  // "pop" exec location
    //
    // Handle remaining registers through special treatment
    //
    if (Debug.evaluate("OS_SwitchAfterISR_ARM")) {  // This is for embOS for ARM
      //
      // Check if this task has been interrupted (i.e., exec location is addr. of OS_Switch() + 12)
      //
      OSSwitch = Debug.evaluate("OS_SwitchAfterISR_ARM");
      if ((aRegs[arm_exec] & ~1) == (OSSwitch + 12)) {
        Interrupted = 1;
      }
      //
      // Restore appropriate register contents
      //
      if (Interrupted == 0) {  // Remaining register contents have NOT been preserved.
        aRegs[arm_r0]  = "0x00000000";                         // unknown after cooperative task switch
        aRegs[arm_r1]  = "0x00000000";                         // unknown after cooperative task switch
        aRegs[arm_r2]  = "0x00000000";                         // unknown after cooperative task switch
        aRegs[arm_r3]  = "0x00000000";                         // unknown after cooperative task switch
        aRegs[arm_r12] = "0x00000000";                         // unknown after cooperative task switch
        aRegs[arm_lr]  = aRegs[arm_exec];                      // Set LR to exec location
        aRegs[arm_psr] = (aRegs[arm_exec] & 1) ? 0x3F : 0x1F;  // Thumb vs. ARM mode?
      } else {                 // Remaining register contents have been preserved.
        aRegs[arm_r0]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" R0
        aRegs[arm_r1]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" R1
        aRegs[arm_r2]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" R2
        aRegs[arm_r3]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" R3
        aRegs[arm_r12] = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" R12
        aRegs[arm_lr]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" LR
        aRegs[arm_pc]  = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" PC
        aRegs[arm_psr] = TargetInterface.peekWord(aRegs[arm_sp]);
        aRegs[arm_sp] += 4;  // "pop" PSR
      }
    } else {                                    // This is for embOS for Cortex-M
      var OSSwitchEnd;
      var v;
      //
      // Check if this task has used the FPU
      //
      v = TargetInterface.peekWord(0xE000ED88);
      if ((v & 0x00F00000) != 0) {                    // Is the FPU enabled (CPACR b23..b20)?
        v = TargetInterface.peekWord(0xE000EF34);
        if ((v & 0xC0000000) != 0) {                  // Is the (lazy) hardware state preservation enabled (FPCCR b31..b30)?
          if ((aRegs[arm_exec] & 0x00000010) == 0) {  // Has this task used the FPU (LR b4)?
            FPU_Used = 1;
          }
        }
      }
      //
      // Check if this task has been interrupted (i.e., PC is located in OS_Switch() function)
      //
      if (FPU_Used == 0) {  // FPU registers have not been preserved, PC is located on stack 6 bytes after current SP
        aRegs[arm_pc] = TargetInterface.peekWord(aRegs[arm_sp] + (4 *  6));
      } else {              // FPU registers have been preserved, PC is located on stack 22 bytes after current SP
        aRegs[arm_pc] = TargetInterface.peekWord(aRegs[arm_sp] + (4 * 22));
      }
      OSSwitch    = Debug.evaluate("OS_Switch");
      OSSwitchEnd = Debug.evaluate("OS_Switch_End");
      if ((aRegs[arm_pc] <= OSSwitch) || (aRegs[arm_pc] >= OSSwitchEnd)) {
        Interrupted = 1;
      }
      //
      // Restore appropriate register contents
      //
      if (FPU_Used == 0) {       // FPU registers have not been preserved, use regular stack layout
        if (Interrupted == 0) {  // Task called OS_Switch(), unwind stack to show previous state.
          aRegs[arm_r0]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R0
          aRegs[arm_r1]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R1
          aRegs[arm_r2]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R2
          aRegs[arm_r3]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R3
          aRegs[arm_r12]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R12
          aRegs[arm_lr]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" LR
          // aRegs[arm_pc] has already been read above
          aRegs[arm_sp]  += 4;  // "pop" PC
          aRegs[arm_psr]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" PSR
          //
          // unwind OS_Switch()
          //
          aRegs[arm_r2]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp] += 4;  // "pop" R2
          aRegs[arm_r3]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp] += 4;  // "pop" R3
          aRegs[arm_pc]  = aRegs[arm_lr];
        } else {                 // Task was preempted, no additional unwinding required.
          aRegs[arm_r0]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R0
          aRegs[arm_r1]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R1
          aRegs[arm_r2]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R2
          aRegs[arm_r3]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R3
          aRegs[arm_r12]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" R12
          aRegs[arm_lr]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" LR
          // aRegs[arm_pc] has already been read above
          aRegs[arm_sp]  += 4;  // "pop" PC
          aRegs[arm_psr]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;  // "pop" APSR
        }
      } else {                   // FPU registers have been preserved, use extended stack layout
        if (Interrupted == 0) {  // Task called OS_Switch(), unwind stack to show previous state.
          aRegs[arm_sp]  += (4 * 16);  // "pop" S16..S31
          aRegs[arm_r0]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R0
          aRegs[arm_r1]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R1
          aRegs[arm_r2]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R2
          aRegs[arm_r3]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R3
          aRegs[arm_r12]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R12
          aRegs[arm_lr]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" LR
          // aRegs[arm_pc] has already been read above
          aRegs[arm_sp]  += 4;         // "pop" PC
          aRegs[arm_psr]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" PSR
          aRegs[arm_sp]  += (4 * 18);  // "pop" S0..S15, FPSCR, and Res.
          //
          // unwind OS_Switch()
          //
          aRegs[arm_r2]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp] += 4;         // "pop" R2
          aRegs[arm_r3]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp] += 4;         // "pop" R3
          aRegs[arm_pc]  = aRegs[arm_lr];
        } else {                 // Task was preempted, no additional unwinding required.
          aRegs[arm_sp]  += (4 * 16);  // "pop" S16..S31
          aRegs[arm_r0]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R0
          aRegs[arm_r1]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R1
          aRegs[arm_r2]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R2
          aRegs[arm_r3]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R3
          aRegs[arm_r12]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" R12
          aRegs[arm_lr]   = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" LR
          // aRegs[arm_pc] has already been read above
          aRegs[arm_sp]  += 4;         // "pop" PC
          aRegs[arm_psr]  = TargetInterface.peekWord(aRegs[arm_sp]);
          aRegs[arm_sp]  += 4;         // "pop" APSR
          aRegs[arm_sp]  += (4 * 18);  // "pop" S0..S15, FPSCR, and Res.
        }
      }
    }
    return aRegs;
  }
}

/*********************************************************************
*
*       init()
*
*  Functions description:
*    This function describes the look of the threads window.
*/
function init() {
  Threads.setColumns("Priority", "Id", "Name", "Status", "Timeout", "Stack info", "Run count", "Time slice", "Task events");
  Threads.setSortByNumber("Priority");
}

/*********************************************************************
*
*       getstate()
*
*  Parameters
*    task: Task Id
*
*  Functions description:
*    This function returns the state of a task.
*/
function getState(task) {
  var WaitObj;
  var sName;
  var sText;

  WaitObj = Debug.evaluate("(((OS_TASK*)" + task.pWaitList + ")->pWaitList)");
  sName   = GetName(WaitObj);
  sText   = (WaitObj) ? (" 0x" + WaitObj.toString(16).toUpperCase()) : "n.a.";
  if (sName != "") {
    sText += " (" + sName + ")";
  }

  if ((task.Stat & TS_MASK_SUSPEND_CNT) != 0) {
    return "Suspended";
  } else {
    switch (task.Stat & (TS_MASK_TIMEOUT | TS_MASK_STATE)) {
    case TS_READY:
      return "Ready";
    case TS_WAIT_ANY:
      return "Blocked";
    case TS_WAIT_EVENT:
      return "Waiting for Task Event" + sText;
    case TS_WAIT_EVENTOBJ:
      return "Waiting for Event Object" + sText;
    case TS_WAIT_MBNE:
      return "Waiting for message in Mailbox" + sText;
    case TS_WAIT_MBNF:
      return "Waiting for space in Mailbox" + sText;
    case TS_WAIT_MEMF:
    case TS_WAIT_MEMF_old:
      return "Waiting for Memory Pool" + sText;
    case TS_WAIT_QNE:
      return "Waiting for message in Queue" + sText;
    case TS_WAIT_QNF:
      return "Waiting for space in Queue" + sText;
    case TS_WAIT_SEMANZ:
      return "Waiting for C-Semaphore" + sText;
    case TS_WAIT_SEMAZ:
      return "Waiting for R-Semaphore" + sText;
    case TS_MASK_TIMEOUT | TS_READY:
      return "Delay";
    case TS_MASK_TIMEOUT | TS_WAIT_ANY:
      return "Blocked";
    case TS_MASK_TIMEOUT | TS_WAIT_EVENT:
      return "Waiting for Task Event";
    case TS_MASK_TIMEOUT | TS_WAIT_EVENTOBJ:
      return "Waiting for Event Object" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_MBNE:
      return "Waiting for message in Mailbox" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_MBNF:
      return "Waiting for space in Mailbox" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_MEMF:
    case TS_MASK_TIMEOUT | TS_WAIT_MEMF_old:
      return "Waiting for Memory Pool" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_QNE:
      return "Waiting for message in Queue" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_QNF:
      return "Waiting for space in Queue" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_SEMANZ:
      return "Waiting for C-Semaphore" + sText;
    case TS_MASK_TIMEOUT | TS_WAIT_SEMAZ:
      return "Waiting for R-Semaphore" + sText;
    default:
      return "Invalid";
    }
  }
}

/*********************************************************************
*
*       GetName()
*
*  Parameters
*    Address: Object address
*
*  Functions description:
*    Returns an object name
*/
function GetName(Address) {
  var p;
  var pObjID;
  var s;

  p = Debug.evaluate("OS_pObjNameRoot");
  if (p == NULL) {
    return "";
  }
  pObjID = Debug.evaluate("(*(OS_OBJNAME*)" + p + ").pOSObjID");
  while ((p != 0) && (pObjID != Address)) {
    p = Debug.evaluate("(OS_OBJNAME*)(*(OS_OBJNAME*)" + p + ").pNext");
    if (p != 0) {
      pObjID = Debug.evaluate("(*(OS_OBJNAME*)" + p + ").pOSObjID");
    }
  }
  if (p != 0) {
    s = Debug.evaluate("(const char*)(*(OS_OBJNAME*)" + p + ").sName");
  } else {
    s = "";
  }
  return s;
}

/*********************************************************************
*
*       update()
*
*  Functions description:
*    This function is called to update the threads window and its
*    entries upon debug stop.
*/
function update() {
  var pTask;
  var pCurrentTask;
  var OS_TASK;
  var Id;
  var TaskName;
  var NumActivations;
  var StackUsage;
  var TimeSliceReload;
  var TimeSliceRem;

  //
  // Initially, clear entire threads window
  //
  Threads.clear();
  //
  // Retrieve start of linked task list from target
  //
  pTask = Debug.evaluate("OS_Global->pTask");
  //
  // Create new queue if at least one task is present
  //
  if (pTask != 0) {
    Threads.newqueue("Task List");
    //
    // Retrieve currently executing task, if any
    //
    pCurrentTask = Debug.evaluate("OS_Global->pCurrentTask");
  }
  //
  // Iterate through linked list of tasks and create an entry to the queue for each
  //
  while (pTask != 0) {
    //
    // Get a pointer to this task control block
    //
    OS_TASK = Debug.evaluate("*(OS_TASK*)" + pTask);
    //
    // Retrieve Task ID
    //
    Id = Debug.evaluate("(OS_TASK*)" + pTask);
    //
    // Retrieve TaskName (unavailable in some libmodes)
    //
    TaskName = Debug.evaluate("(const char*)(*(OS_TASK*)" + pTask + ").Name");
    TaskName = (TaskName != NULL) ? OS_TASK.Name : "n.a.";
    //
    // Retrieve NumActivations (unavailable in some libmodes)
    //
    NumActivations = Debug.evaluate("(unsigned int*)(*(OS_TASK*)" + pTask + ").NumActivations");
    NumActivations = (NumActivations != NULL) ? OS_TASK.NumActivations : "n.a.";
    //
    // Retrieve Stackinfo (unavailable in some libmodes)
    //
    StackUsage = Debug.evaluate("(unsigned int*)(*(OS_TASK*)" + pTask + ").StackSize");
    if (StackUsage != NULL) {
      var MaxStackUsed;
      var abStack;
      var i;

      abStack = TargetInterface.peekBytes(OS_TASK.pStackBot, OS_TASK.StackSize);
      for (i = 0; i < OS_TASK.StackSize; i++) {
        if (abStack[i].toString(16) != "cd") {
          break;
        }
      }
      MaxStackUsed = OS_TASK.StackSize - i;
      StackUsage   = MaxStackUsed + " / " + OS_TASK.StackSize + " @ 0x" + OS_TASK.pStackBot.toString(16).toUpperCase();
    } else {
      StackUsage = "n.a.";
    }
    //
    // Retrieve TimeSliceReload and TimeSliceRem (unavailable in some libmodes)
    //
    TimeSliceReload = Debug.evaluate("(unsigned int*)(*(OS_TASK*)" + pTask + ").TimeSliceReload");
    TimeSliceReload = (TimeSliceReload != NULL) ? OS_TASK.TimeSliceReload : "n.a.";
    TimeSliceRem    = Debug.evaluate("(unsigned int*)(*(OS_TASK*)" + pTask + ").TimeSliceRem");
    TimeSliceRem    = (TimeSliceRem != NULL) ? OS_TASK.TimeSliceRem : "n.a.";
    //
    // Add task to queue
    //
    Threads.add(OS_TASK.Priority,                                          // Priority
                "0x" + Id.toString(16).toUpperCase(),                      // ID
                TaskName,                                                  // Name
                (pTask == pCurrentTask) ? "Executing" : getState(OS_TASK), // Status
                OS_TASK.Timeout,                                           // Timeout
                StackUsage,                                                // Stack info
                NumActivations,                                            // Run count
                TimeSliceRem + " / " + TimeSliceReload,                    // Time slice
                "0x" + OS_TASK.Events.toString(16).toUpperCase(),          // Events
                //
                // If task is executing, getregs() must not be called. We therefore pass a null pointer.
                // If task is inactive, getregs() must be called. We therefore pass a pointer to this task.
                //
                (pTask == pCurrentTask) ? [] : pTask
               );
    pTask = OS_TASK.pNext;
  }
}

/****** End Of File *************************************************/
