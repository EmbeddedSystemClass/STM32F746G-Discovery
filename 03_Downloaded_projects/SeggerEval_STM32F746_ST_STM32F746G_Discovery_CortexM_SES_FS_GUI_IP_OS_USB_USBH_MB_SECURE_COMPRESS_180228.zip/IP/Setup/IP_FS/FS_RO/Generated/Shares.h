/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Shares.h
Purpose : Automatically created from html\Shares.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __SHARES_H__
#define __SHARES_H__

#define SHARES_SIZE 4491

extern const unsigned char shares_file[4491];

#endif  //__SHARES_H__

/****** End Of File *************************************************/
