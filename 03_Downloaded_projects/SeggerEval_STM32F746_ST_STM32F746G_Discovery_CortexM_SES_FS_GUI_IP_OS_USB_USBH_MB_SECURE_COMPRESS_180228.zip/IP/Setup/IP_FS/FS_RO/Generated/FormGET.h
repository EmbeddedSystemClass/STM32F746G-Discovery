/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : FormGET.h
Purpose : Automatically created from html\FormGET.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __FORMGET_H__
#define __FORMGET_H__

#define FORMGET_SIZE 2881

extern const unsigned char formget_file[2881];

#endif  //__FORMGET_H__

/****** End Of File *************************************************/
