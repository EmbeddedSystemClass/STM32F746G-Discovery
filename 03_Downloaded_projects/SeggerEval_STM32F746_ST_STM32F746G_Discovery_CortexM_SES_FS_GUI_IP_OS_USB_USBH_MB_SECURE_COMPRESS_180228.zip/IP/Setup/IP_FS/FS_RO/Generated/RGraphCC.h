/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : RGraphCC.h
Purpose : Automatically created from html\RGraphCC.js using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __RGRAPHCC_H__
#define __RGRAPHCC_H__

#define RGRAPHCC_SIZE 56552

extern const unsigned char rgraphcc_file[56552];

#endif  //__RGRAPHCC_H__

/****** End Of File *************************************************/
