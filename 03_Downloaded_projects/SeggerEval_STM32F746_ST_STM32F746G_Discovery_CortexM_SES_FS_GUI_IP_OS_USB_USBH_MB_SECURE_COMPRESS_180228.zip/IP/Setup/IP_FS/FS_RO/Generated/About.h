/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : About.h
Purpose : Automatically created from html\About.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __ABOUT_H__
#define __ABOUT_H__

#define ABOUT_SIZE 1858

extern const unsigned char about_file[1858];

#endif  //__ABOUT_H__

/****** End Of File *************************************************/
