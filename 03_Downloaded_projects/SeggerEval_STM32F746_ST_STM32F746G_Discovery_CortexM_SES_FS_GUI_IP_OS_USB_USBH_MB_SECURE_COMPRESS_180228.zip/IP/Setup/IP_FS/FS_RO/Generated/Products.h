/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Products.h
Purpose : Automatically created from html\Products.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __PRODUCTS_H__
#define __PRODUCTS_H__

#define PRODUCTS_SIZE 3491

extern const unsigned char products_file[3491];

#endif  //__PRODUCTS_H__

/****** End Of File *************************************************/
