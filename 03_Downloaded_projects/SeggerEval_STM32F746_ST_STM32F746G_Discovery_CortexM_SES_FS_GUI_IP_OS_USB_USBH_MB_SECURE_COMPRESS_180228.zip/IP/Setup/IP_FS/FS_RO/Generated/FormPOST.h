/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : FormPOST.h
Purpose : Automatically created from html\FormPOST.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __FORMPOST_H__
#define __FORMPOST_H__

#define FORMPOST_SIZE 2887

extern const unsigned char formpost_file[2887];

#endif  //__FORMPOST_H__

/****** End Of File *************************************************/
