/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : RGraphCE.h
Purpose : Automatically created from html\RGraphCE.js using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __RGRAPHCE_H__
#define __RGRAPHCE_H__

#define RGRAPHCE_SIZE 27594

extern const unsigned char rgraphce_file[27594];

#endif  //__RGRAPHCE_H__

/****** End Of File *************************************************/
