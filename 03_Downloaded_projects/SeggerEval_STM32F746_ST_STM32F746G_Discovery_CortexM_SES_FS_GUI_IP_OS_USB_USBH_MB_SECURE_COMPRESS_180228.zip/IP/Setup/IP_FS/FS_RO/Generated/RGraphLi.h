/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : RGraphLi.h
Purpose : Automatically created from html\RGraphLi.js using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __RGRAPHLI_H__
#define __RGRAPHLI_H__

#define RGRAPHLI_SIZE 62868

extern const unsigned char rgraphli_file[62868];

#endif  //__RGRAPHLI_H__

/****** End Of File *************************************************/
