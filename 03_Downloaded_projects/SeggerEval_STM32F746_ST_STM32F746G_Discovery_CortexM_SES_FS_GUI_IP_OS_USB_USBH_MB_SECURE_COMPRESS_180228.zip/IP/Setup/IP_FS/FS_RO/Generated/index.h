/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : index.h
Purpose : Automatically created from html\index.htm using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __INDEX_H__
#define __INDEX_H__

#define INDEX_SIZE 538

extern const unsigned char index_file[538];

#endif  //__INDEX_H__

/****** End Of File *************************************************/
