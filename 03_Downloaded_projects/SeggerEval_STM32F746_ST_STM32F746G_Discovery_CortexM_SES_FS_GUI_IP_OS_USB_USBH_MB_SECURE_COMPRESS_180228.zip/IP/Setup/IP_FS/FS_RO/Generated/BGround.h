/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : BGround.h
Purpose : Automatically created from html\BGround.png using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __BGROUND_H__
#define __BGROUND_H__

#define BGROUND_SIZE 1726

extern const unsigned char bground_file[1726];

#endif  //__BGROUND_H__

/****** End Of File *************************************************/
