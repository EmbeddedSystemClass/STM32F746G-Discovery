/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Styles.h
Purpose : Automatically created from html\Styles.css using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __STYLES_H__
#define __STYLES_H__

#define STYLES_SIZE 2797

extern const unsigned char styles_file[2797];

#endif  //__STYLES_H__

/****** End Of File *************************************************/
