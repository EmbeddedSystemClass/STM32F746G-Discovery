/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : events.h
Purpose : Automatically created from html\events.js using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __EVENTS_H__
#define __EVENTS_H__

#define EVENTS_SIZE 4328

extern const unsigned char events_file[4328];

#endif  //__EVENTS_H__

/****** End Of File *************************************************/
