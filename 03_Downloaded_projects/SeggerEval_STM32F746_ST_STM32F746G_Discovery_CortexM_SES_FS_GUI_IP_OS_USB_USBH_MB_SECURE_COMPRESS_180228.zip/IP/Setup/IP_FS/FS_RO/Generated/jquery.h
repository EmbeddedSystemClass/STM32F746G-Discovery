/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : jquery.h
Purpose : Automatically created from html\jquery.js using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __JQUERY_H__
#define __JQUERY_H__

#define JQUERY_SIZE 93106

extern const unsigned char jquery_file[93106];

#endif  //__JQUERY_H__

/****** End Of File *************************************************/
