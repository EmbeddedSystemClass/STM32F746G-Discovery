/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File        : GUI_Version.h
Purpose     : Include file defining current GUI version
---------------------------END-OF-HEADER------------------------------
*/

#ifndef  GUI_VERSION_H
#define  GUI_VERSION_H

#define GUI_VERSION 54606

#endif   /* Avoid multiple inclusion */

/*************************** End of file ****************************/
