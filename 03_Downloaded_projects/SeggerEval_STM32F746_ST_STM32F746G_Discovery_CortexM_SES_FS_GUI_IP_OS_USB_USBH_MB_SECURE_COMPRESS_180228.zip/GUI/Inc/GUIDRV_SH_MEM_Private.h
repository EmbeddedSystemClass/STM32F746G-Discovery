/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File        : GUIDRV_SH_MEM_Private.h
Purpose     : Private header file  for GUIDRV_SH_MEM driver
---------------------------END-OF-HEADER------------------------------
*/

#ifndef GUIDRV_SH_MEM_PRIVATE_H
#define GUIDRV_SH_MEM_PRIVATE_H

#include "GUIDRV_SH_MEM.h"

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
#define DRIVER_CONTEXT DRIVER_CONTEXT_SH_MEM

#define XY2OFF(pContext, x, y) ((x >> 3) + (y * pContext->BytesPerLine))

#define XY2OFF3(pContext, x, y) (((x * 3) / 24) * 3 + (pContext->BytesPerLine * y))

/*********************************************************************
*
*       Types
*
**********************************************************************
*/
typedef struct DRIVER_CONTEXT DRIVER_CONTEXT;

struct DRIVER_CONTEXT {
  GUI_PORT_API     HW_API;
  int              xSize, ySize;
  int              ySizePhys;
  int              BytesPerLine;
  GUI_TIMER_HANDLE hTimer;
  unsigned         Period;                                                 // Period used for toggling VCOM
  void          (* pfToggleVCOM)(void);                                    // Routine to be called for toggling VCOM
  void          (* pfSendLine)(DRIVER_CONTEXT * pContext, int LineIndex);  // Routine to be used to send one line of data
  U8             * pDirty;                                                 // Pointer to dirty markers
  U8             * pVRAM;                                                  // Pointer to cache
  U8               CacheLocked;                                            // Cache is locked if 1
  U8               IsDirty;                                                // Set to 1 if any bit is dirty
  U8               VCom;                                                   // Current state of VCOM signal
  U8               ExtMode;                                                // Setting of EXTMODE configuration pin
  U8               BitMode;                                                // 8- or 10-bit line addressing
  U8               AddressBitOrder;                                        // Either LSB first (0) or MSB first (1)
};

extern const U16 GUIDRV_SH_MEM__aMirror10[1024];

void    GUIDRV_SH_MEM__SendCacheOnDemand(DRIVER_CONTEXT * pContext, int y0, int y1);
void  * GUIDRV_SH_MEM__GetDevData       (GUI_DEVICE * pDevice, int Index);
void    GUIDRV_SH_MEM__GetRect          (GUI_DEVICE * pDevice, LCD_RECT * pRect);
void    GUIDRV_SH_MEM__SetOrg           (GUI_DEVICE * pDevice, int x, int y);
void (* GUIDRV_SH_MEM__GetDevFunc       (GUI_DEVICE ** ppDevice, int Index))(void);
void (* GUIDRV_SH_MEM_3__GetDevFunc     (GUI_DEVICE ** ppDevice, int Index))(void);
void  * GUIDRV_SH_MEM_3__GetDevData     (GUI_DEVICE * pDevice, int Index);

#endif // GUIDRV_SH_MEM_PRIVATE_H

/*************************** End of file ****************************/
