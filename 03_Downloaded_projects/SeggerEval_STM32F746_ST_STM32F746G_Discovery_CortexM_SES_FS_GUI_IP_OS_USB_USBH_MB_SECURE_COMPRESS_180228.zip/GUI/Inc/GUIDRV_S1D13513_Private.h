/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*       (c) 2003 - 2018  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File        : GUIDRV_S1D13513_Private.h
Purpose     : Interface definition for GUIDRV_S1D13513 driver
---------------------------END-OF-HEADER------------------------------
*/

#include "GUIDRV_S1D13513.h"
#include "GUIDRV_NoOpt_1_8.h"

#ifndef GUIDRV_S1D13513_PRIVATE_H
#define GUIDRV_S1D13513_PRIVATE_H

#if defined(__cplusplus)
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
/*********************************************************************
*
*       Configuration
*/
#ifndef   LCD_WRITE_BUFFER_SIZE
  #define LCD_WRITE_BUFFER_SIZE 1920
#endif
#ifndef   BITBLT_THRESHOLD
  #define BITBLT_THRESHOLD 200
#endif

/*********************************************************************
*
*       SFR definitions
*/
//
// Host Interface Registers
//
#define REG_HOST_BASE                0x0000     // HOST INTERFACE REGISTERS
#define REG0000_PRODUCT_ID_0         0x0000     // Product ID Register 0 [READONLY]
#define REG0002_PRODUCT_ID_1         0x0002     // Product ID Register 1 [READONLY]
#define REG0004_MEMORY_SIZE          0x0004     // Embedded Memory Size Register [READONLY]
#define REG0010_MEM_OFFSET_RECT      0x0010     // Indirect Interface Rectangular Memory Address Offset Register
#define REG0012_II_MEM_ADDR_0        0x0012     // Indirect Interface Memory Address Register 0
#define REG0014_II_MEM_ADDR_1        0x0014     // Indirect Interface Memory Address Register 1
#define REG0016_RECT_MEM_WIDTH       0x0016     // Indirect Interface Rectangular Memory Width Register
#define REG0018_II_DATA_PORT         0x0018     // Indirect Interface Memory Access Data Port Register
#define REG0020_IRQ_STATUS           0x0020     // Interrupt Status Register
#define REG0022_IRQ_CONTROL          0x0022     // Interrupt Control Register
#define REG0024_CYCLE_TIMEOUT        0x0024     // Cycle Time-Out Control Register
#define REG0026_BUS_ERROR_STATUS     0x0026     // Bus Error Status Register
#define REG0028_BUS_ERROR_IRQ        0x0028     // Bus Error Interrupt Enable/Disable Register
#define REG002A_IRQ_PIN_CONTROL      0x002A     // Interrupt Pin Control Register
#define REG0030_HOST_PAGE_UNIT_0     0x0030     // Host SDRAM Page 0 Start Address Register
#define REG0032_HOST_PAGE_UNIT_1     0x0032     // Host SDRAM Page 1 Start Address Register
#define REG0034_HOST_PAGE_UNIT_2     0x0034     // Host SDRAM Page 2 Start Address Register
#define REG0036_HOST_PAGE_UNIT_3     0x0036     // Host SDRAM Page 3 Start Address Register
#define REG0044_TX49_HOST_CONFIG     0x0044     // TX49 HOST Configuration Register
#define REG_HOST_END                 0x0046

//
// System Control Registers
//
#define REG_SYSTEM_BASE              0x0406     // SYSTEM CONTROL REGISTERS
#define REG0406_CNF_STATUS           0x0406     // Configuration Pins Status Register [READONLY]
#define REG0408_OSC1_CONTROL         0x0408     // OSC1 Control Register
#define REG040A_OSC2_CONTROL         0x040A     // OSC2 Control Register
#define REG040C_PLL1_CONFIG_0        0x040C     // PLL1 Configuration Register 0
#define REG040E_PLL1_CONFIG_1        0x040E     // PLL1 Configuration Register 1
#define REG0410_PLL1_CONTROL         0x0410     // PLL1 Control Register
#define REG0414_PLL2_CONFIG_0        0x0414     // PLL2 Configuration Register 0
#define REG0416_PLL2_CONFIG_1        0x0416     // PLL2 Configuration Register 1
#define REG0418_PLL2_CONTROL         0x0418     // PLL2 Control Register
#define REG0424_SYSCLK_CONTROL       0x0424     // PLL1 Source Divide Select Register
#define REG0426_PLL1_CONTROL_0       0x0426     // PLL1 Control Register 0
#define REG0428_PLL1_BYPASS          0x0428     // PLL1 Bypass Select Register
#define REG042C_KEYCLK_CONTROL       0x042C     // Key Clock Control Register
#define REG042E_PWMCLK_CONTROL       0x042E     // PWM Clock Control Register
#define REG0430_I2CCLK_CONTROL       0x0430     // I2C Clock Control Register
#define REG0440_PLL2_SOURCE          0x0440     // PLL2 Source Select Register
#define REG0442_PLL2_DIVIDE          0x0442     // PLL2 Source Divide Select Register
#define REG0444_PLL2_REF_CONTROL     0x0444     // PLL2 Reference Clock Control Register
#define REG0446_LCDDCLK_DIVIDE       0x0446     // LCDDCLK Divide Select Register
#define REG0448_LCDSCLK_DIVIDE       0x0448     // LCDSCLK Divide Select Register
#define REG0460_SOFTWARE_RESET       0x0460     // Software Reset Register
#define REG0462_CLOCK_ENABLE         0x0462     // Clock Enable Register
#define REG0464_GPIOCD_PULLDOWN      0x0464     // GPIOC&D Pull-Down Resistor Control Register
#define REG0466_GPIOEF_PULLDOWN      0x0466     // GPIOE&F Pull-Down Resistor Control Register [RESERVED]
#define REG0468_GPIOGH_PULLDOWN      0x0468     // GPIOG&H Pull-Down Resistor Control Register
#define REG046A_MEMDQ_PULLDOWN_0     0x046A     // MEMDQ Pull-Down Resistor Control Register 0
#define REG046C_MEMDQ_PULLDOWN_1     0x046C     // MEMDQ Pull-Down Resistor Control Register 1
#define REG046E_CNF_PULLDOWN         0x046E     // Configuration Pins Pull-Down Resistor Control Register
#define REG0470_POWER_DOWN_MODE      0x0470     // Power Down Mode Control Register
#define REG0472_HOST_BUS_RESET       0x0472     // Host Interface Bus Reset Control Register
#define REG_SYSTEM_END               0x0474

//
// LCD Panel Configuration Registers
//
#define REG_LCD_BASE                 0x0800     // LCD PANEL CONFIGURATION REGISTERS
#define REG0800_LCD_PANEL_TYPE       0x0800     // LCD Panel Type Select Register
#define REG0802_HT                   0x0802     // LCD Horizontal Total Register
#define REG0804_HDP                  0x0804     // LCD Horizontal Display Period Register
#define REG0806_HDPS                 0x0806     // LCD Horizontal Display Period Start Position Register
#define REG0808_HPW                  0x0808     // LCD Horizontal Pulse Width Register
#define REG080A_HPS                  0x080A     // LCD Horizontal Pulse Start Register
#define REG080C_VT                   0x080C     // LCD Vertical Total Register
#define REG080E_VDP                  0x080E     // LCD Vertical Display Period Register
#define REG0810_VDPS                 0x0810     // LCD Vertical Display Period Start Position Register
#define REG0812_VPW                  0x0812     // LCD Vertical Pulse Width Register
#define REG0814_VPS                  0x0814     // LCD Vertical Pulse Start Register
#define REG0816_LCD_SER_CONFIG       0x0816     // LCD Serial Interface Configuration Register
#define REG0818_LCD_STATUS           0x0818     // LCD Status Register
#define REG081A_LCD_VSYNC_IRQ        0x081A     // LCD VSYNC Interrupt Delay Register
#define REG081C_LCD_SER_CMDPARAM     0x081C     // LCD Serial Command/Parameter Register
#define REG_LCD_END                  0x081E

//
// HR-TFT Configuration Registers
//
#define REG_EXTENDED_BASE            0x081E     // EXTENDED PANEL CONFIGURATION REGISTERS
#define REG081E_MOD_SERIAL_CMD       0x081E     // MOD/Serial Command Register
#define REG0820_HRTFT_CONFIG         0x0820     // HR-TFT Configuration Register
#define REG0822_HRTFT_CLS_WIDTH      0x0822     // HR-TFT CLS Width Register
#define REG0824_HRTFT_PS1_RISING     0x0824     // HR-TFT PS1 Rising Edge Register
#define REG0826_HRTFT_PS2_RISING     0x0826     // HR-TFT PS2 Rising Edge Register
#define REG0828_HRTFT_PS2_TOGGLE     0x0828     // HR-TFT PS2 Toggle Width Register
#define REG082A_HRTFT_PS3_WIDTH      0x082A     // HR-TFT PS3 Signal Width Register
#define REG082C_HRTFT_REV_TOGGLE     0x082C     // HR-TFT REV Toggle Point Register
#define REG082E_HRTFT_PS12_END       0x082E     // HR-TFT PS1/2 End Register
#define REG_EXTENDED_END             0x0830

//
// LCD Display Mode Registers
//
#define REG_DISPLAY_BASE             0x0830     // LCD DISPLAY MODE REGISTERS
#define REG0830_DISPLAY_MODE_0       0x0830     // Display Mode Setting Register 0
#define REG0832_DISPLAY_MODE_1       0x0832     // Display Mode Setting Register 1
#define REG0834_DISPLAY_MODE_2       0x0834     // Display Mode Setting Register 2
#define REG0836_PIP2_ALPHA_BLEND     0x0836     // PIP2 Window Alpha Blending Mode Register
#define REG0838_PIP2_XPARENT_RED     0x0838     // PIP2 Window Transparent Key Color Red Register
#define REG083A_PIP2_XPARENT_GRN     0x083A     // PIP2 Window Transparent Key Color Green Register
#define REG083C_PIP2_XPARENT_BLU     0x083C     // PIP2 Window Transparent Key Color Blue Register
#define REG083E_GAMMA_CONTROL        0x083E     // Gamma Control Register
#define REG0840_GAMMA_ADDRESS        0x0840     // Gamma Table Access Address Port Register
#define REG0842_GAMMA_DATA           0x0842     // Gamma Table Access Data Port Register
#define REG0844_PSEUDO_COLOR         0x0844     // Pseudo Color Mode Register
#define REG0846_FIFO1_THRESHOLD      0x0846     // Display FIFO1 Threshold Register
#define REG0848_FIFO2_THRESHOLD      0x0848     // Display FIFO2 Threshold Register
#define REG084A_PIP1_X_START         0x084A     // PIP1 Window X Start Position Register
#define REG084C_PIP1_X_END           0x084C     // PIP1 Window X End Position Register
#define REG084E_PIP1_Y_START         0x084E     // PIP1 Window Y Start Position Register
#define REG0850_PIP1_Y_END           0x0850     // PIP1 Window Y End Position Register
#define REG0852_PIP2_X_START         0x0852     // PIP2 Window X Start Position Register
#define REG0854_PIP2_X_END           0x0854     // PIP2 Window X End Position Register
#define REG0856_PIP2_Y_START         0x0856     // PIP2 Window Y Start Position Register
#define REG0858_PIP2_Y_END           0x0858     // PIP2 Window Y End Position Register
#define REG085A_MAIN_FBUF_SADDR0     0x085A     // Main Window Front Buffer Start Address Register 0
#define REG085C_MAIN_FBUF_SADDR1     0x085C     // Main Window Front Buffer Start Address Register 1
#define REG085E_PIP1_FBUF_SADDR0     0x085E     // PIP1 Window Front Buffer Start Address Register 0
#define REG0860_PIP1_FBUF_SADDR1     0x0860     // PIP1 Window Front Buffer Start Address Register 1
#define REG0862_PIP2_FBUF_SADDR0     0x0862     // PIP2 Window Front Buffer Start Address Register 0
#define REG0864_PIP2_FBUF_SADDR1     0x0864     // PIP2 Window Front Buffer Start Address Register 1
#define REG0866_BBUF_SADDR_0         0x0866     // Main/PIP1/PIP2 Window Back Buffer Start Address Register 0
#define REG0868_BBUF_SADDR_1         0x0868     // Main/PIP1/PIP2 Window Back Buffer Start Address Register 1
#define REG086A_MAIN_FBUF_STRIDE     0x086A     // Main Window Front Buffer Line Address Offset Register
#define REG086C_PIP1_FBUF_STRIDE     0x086C     // PIP1 Window Front Buffer Line Address Offset Register
#define REG086E_PIP2_FBUF_STRIDE     0x086E     // PIP2 Window Front Buffer Line Address Offset Register
#define REG0870_BBUF_STRIDE          0x0870     // Main/PIP1/PIP2 Window Front Buffer Line Address Offset Register
#define REG_DISPLAY_END              0x0872

//
// GPIO Registers
//
#define REG_GPIO_BASE                0x0C00     // GPIO REGISTERS
#define REG0C00_GPIOA_DATA           0x0C00     // GPIOA Data Register
#define REG0C02_GPIOA_PIN            0x0C02     // GPIOA Pin Function Register
#define REG0C04_GPIOB_DATA           0x0C04     // GPIOB Data Register
#define REG0C06_GPIOB_PIN            0x0C06     // GPIOB Pin Function Register
#define REG0C08_GPIOC_DATA           0x0C08     // GPIOC Data Register
#define REG0C0A_GPIOC_PIN            0x0C0A     // GPIOC Pin Function Register
#define REG0C0C_GPIOD_DATA           0x0C0C     // GPIOD Data Register
#define REG0C0E_GPIOD_PIN            0x0C0E     // GPIOD Pin Function Register
#define REG0C10_GPIOE_DATA           0x0C10     // GPIOE Data Register
#define REG0C12_GPIOE_PIN            0x0C12     // GPIOE Pin Function Register
#define REG0C14_GPIOF_DATA           0x0C14     // GPIOF Data Register
#define REG0C16_GPIOF_PIN            0x0C16     // GPIOF Pin Function Register
#define REG0C18_GPIOG_DATA           0x0C18     // GPIOG Data Register
#define REG0C1A_GPIOG_PIN            0x0C1A     // GPIOG Pin Function Register
#define REG0C1C_GPIOH_DATA           0x0C1C     // GPIOH Data Register
#define REG0C1E_GPIOH_PIN            0x0C1E     // GPIOH Pin Function Register
#define REG0C20_GPIOI_DATA           0x0C20     // GPIOI Data Register
#define REG0C22_GPIOI_PIN            0x0C22     // GPIOI Pin Function Register
#define REG0C24_GPIOAB_IRQ_TYPE      0x0C24     // GPIOA&B IRQ Type Register
#define REG0C26_GPIOAB_IRQ_POL       0x0C26     // GPIOA&B IRQ Polarity Register
#define REG0C28_GPIOAB_IRQ_EN        0x0C28     // GPIOA&B IRQ Enable Register
#define REG0C2A_GPIOAB_IRQ_STAT      0x0C2A     // GPIOA&B IRQ Status and Clear Register
#define REG_GPIO_END                 0x0C2C

//
// Sprite Registers
//
#define REG_SPRITE_BASE              0x1000     // SPRITE REGISTERS
#define REG1000_SN_GENERAL_CTRL      0x1000     // Sprite #n General Control Register
#define REG1004_SN_IMAGE_SADDR_0     0x1004     // Sprite #n Image Start Address Register 0
#define REG1006_SN_IMAGE_SADDR_1     0x1006     // Sprite #n Image Start Address Register 1
#define REG1008_SN_ROTAT_SADDR_0     0x1008     // Sprite #n Image Rotated Start Address Register 0
#define REG100A_SN_ROTAT_SADDR_1     0x100A     // Sprite #n Image Rotated Start Address Register 1
#define REG100C_SN_X_POSITION        0x100C     // Sprite #n X Position Register
#define REG100E_SN_Y_POSITION        0x100E     // Sprite #n Y Position Register
#define REG1010_SN_FRAME_WIDTH       0x1010     // Sprite #n Frame Width Register
#define REG1012_SN_FRAME_HEIGHT      0x1012     // Sprite #n Frame Height Register
#define REG1014_SN_X_OFFSET          0x1014     // Sprite #n Reference Point X Offset Register
#define REG1016_SN_Y_OFFSET          0x1016     // Sprite #n Reference Point Y Offset Register
#define REG1018_SN_TRANSPARENCY      0x1018     // Sprite #n Transparency Color / Texture Alpha Register
#define REG101A_SN_COLOR_FORMAT      0x101A     // Sprite #n Color Format Register
#define REG101C_SN_FRAME_SEQ_0       0x101C     // Sprite #n Frame Sequence Register 0
#define REG101E_SN_FRAME_SEQ_1       0x101E     // Sprite #n Frame Sequence Register 1
#define REG1020_SN_FRAME_SEQ_2       0x1020     // Sprite #n Frame Sequence Register 2
#define REG1022_SN_FRAME_SEQ_3       0x1022     // Sprite #n Frame Sequence Register 3
#define REG1024_SN_FRAME_SEQ_4       0x1024     // Sprite #n Frame Sequence Register 4
#define REG1026_SN_FRAME_SEQ_5       0x1026     // Sprite #n Frame Sequence Register 5
#define REG1028_SN_FRAME_SEQ_6       0x1028     // Sprite #n Frame Sequence Register 6
#define REG102A_SN_FRAME_SEQ_7       0x102A     // Sprite #n Frame Sequence Register 7
#define REG102C_SN_VIRT_WIDTH        0x102C     // Sprite #n Virtual Width Register
#define REG102E_SN_VIRT_HEIGHT       0x102E     // Sprite #n Virtual Height Register
#define REG1030_SN_XSCAN_H_0         0x1030     // Sprite #n X Scan Vector H Register 0
#define REG1032_SN_XSCAN_H_1         0x1032     // Sprite #n X Scan Vector H Register 1
#define REG1034_SN_YSCAN_H_0         0x1034     // Sprite #n Y Scan Vector H Register 0
#define REG1036_SN_YSCAN_H_1         0x1036     // Sprite #n Y Scan Vector H Register 1
#define REG1038_SN_XSCAN_V_0         0x1038     // Sprite #n X Scan Vector V Register 0
#define REG103A_SN_XSCAN_V_1         0x103A     // Sprite #n X Scan Vector V Register 1
#define REG103C_SN_YSCAN_V_0         0x103C     // Sprite #n Y Scan Vector V Register 0
#define REG103E_SN_YSCAN_V_1         0x103E     // Sprite #n Y Scan Vector V Register 1
#define REG1040_SN_XSCAN_OFFSET0     0x1040     // Sprite #n X Scan Offset Register 0
#define REG1042_SN_XSCAN_OFFSET1     0x1042     // Sprite #n X Scan Offset Register 1
#define REG1044_SN_YSCAN_OFFSET0     0x1044     // Sprite #n Y Scan Offset Register 0
#define REG1046_SN_YSCAN_OFFSET1     0x1046     // Sprite #n Y Scan Offset Register 1
#define REG1000_IFC_SRC_ADDR_0       0x1000     // IFC Source Image Address Register 0
#define REG1002_IFC_SRC_ADDR_1       0x1002     // IFC Source Image Address Register 1
#define REG1004_IFC_DES_ADDR_0       0x1004     // IFC Destination Image Address Register 0
#define REG1006_IFC_DES_ADDR_1       0x1006     // IFC Destination Image Address Register 1
#define REG1008_IFC_WIDTH            0x1008     // IFC Image Width Register
#define REG100A_IFC_HEIGHT           0x100A     // IFC Image Height Register
#define REG_SPRITE_END               0x100C

//
// Sprite Engine Registers
//
#define REG_SENGINE_BASE             0x1700     // SPRITE ENGINE REGISTERS
#define REG1700_GENERAL_SPRITE       0x1700     // General Sprite Control Register
#define REG1702_SPR_UPDATING         0x1702     // Sprite Registers Updating Control Register [READONLY]
#define REG1704_SPR_TRIGGER          0x1704     // Sprite Frame Sequence Trigger Control Register
#define REG1706_SPR_IRQ_CONTROL      0x1706     // Sprite General Interrupt Control Register
#define REG1708_SPR_IRQ_STATUS       0x1708     // Sprite Interrupt Status Register
#define REG1710_SPR_BUF0_SADDR_0     0x1710     // Sprite Frame Buffer 0 Start Address Register 0
#define REG1712_SPR_BUF0_SADDR_1     0x1712     // Sprite Frame Buffer 0 Start Address Register 1
#define REG1714_SPR_BUF1_SADDR_0     0x1714     // Sprite Frame Buffer 1 Start Address Register 0
#define REG1716_SPR_BUF1_SADDR_1     0x1716     // Sprite Frame Buffer 1 Start Address Register 1
#define REG1780_SN_SEQ_CONTROL       0x1780     // Sprite #n Frame Sequence Control Register
#define REG_SENGINE_END              0x1782

//
// 2D BitBLT Registers
//
#define REG_BITBLT_BASE              0x1800     // 2D BITBLT REGISTERS
#define REG1800_BLT_CONTROL_0        0x1800     // BitBLT Control Register 0
#define REG1802_BLT_CONTROL_1        0x1802     // BitBLT Control Register 1 [WRITEONLY]
#define REG1804_BLT_CONTROL_2        0x1804     // BitBLT Control Register 2
#define REG1808_BLT_COMMAND          0x1808     // BitBLT Command Register
#define REG180A_BLT_RASTER_OP        0x180A     // BitBLT Raster Operation Code Register
#define REG1810_BLT_SRC_SADDR_0      0x1810     // BitBLT Source Start Address Register 0
#define REG1812_BLT_SRC_SADDR_1      0x1812     // BitBLT Source Start Address Register 1
#define REG1814_BLT_SRC_X_POS        0x1814     // BitBLT Source X Position Register
#define REG1816_BLT_SRC_Y_POS        0x1816     // BitBLT Source Y Position Register
#define REG1818_BLT_DES_SADDR_0      0x1818     // BitBLT Destination Start Address Register 0
#define REG181A_BLT_DES_SADDR_1      0x181A     // BitBLT Destination Start Address Register 1
#define REG181C_BLT_DES_X_POS        0x181C     // BitBLT Destination X Position Register
#define REG181E_BLT_DES_Y_POS        0x181E     // BitBLT Destination Y Position Register
#define REG1820_BLT_PAT_SADDR_0      0x1820     // BitBLT Pattern Start Address Register 0
#define REG1822_BLT_PAT_SADDR_1      0x1822     // BitBLT Pattern Start Address Register 1
#define REG1824_BLT_MEM_OFFSET       0x1824     // BitBLT Memory Address Offset Register
#define REG1826_BLT_WIDTH            0x1826     // BitBLT Width Register
#define REG1828_BLT_HEIGHT           0x1828     // BitBLT Height Register
#define REG1830_BLT_CLIP_SADDR_0     0x1830     // BitBLT Clipping Start Address Register 0
#define REG1832_BLT_CLIP_SADDR_1     0x1832     // BitBLT Clipping Start Address Register 1
#define REG1834_BLT_CLIP_START_X     0x1834     // BitBLT Clipping Start X Position Register
#define REG1836_BLT_CLIP_START_Y     0x1836     // BitBLT Clipping Start Y Position Register
#define REG1838_BLT_CLIP_WIDTH       0x1838     // BitBLT Clipping Width Register
#define REG1840_BLT_CLIP_HEIGHT      0x1840     // BitBLT Clipping Height Register
#define REG1842_BLT_CLIP_STATUS      0x1842     // BitBLT Clipping Status Register [READONLY]
#define REG1850_BLT_BG_COLOR_0       0x1850     // BitBLT Background Color Register 0
#define REG1852_BLT_BG_COLOR_1       0x1852     // BitBLT Background Color Register 1
#define REG1854_BLT_FG_COLOR_0       0x1854     // BitBLT Foreground Color Register 0
#define REG1856_BLT_FG_COLOR_1       0x1856     // BitBLT Foreground Color Register 1
#define REG1860_BLT_EXP_START        0x1860     // BitBLT Color Expansion Start Position Register
#define REG1862_BLT_EXP_FORMAT       0x1862     // BitBLT Color Expansion Bit Format Register
#define REG1870_BLT_ALPHA_FORMAT     0x1870     // BitBLT Alpha Blending Source Format Register
#define REG1872_BLT_CONST_ALPHA      0x1872     // BitBLT Constant Alpha Register
#define REG1874_BLT_ALPHA_VALUE      0x1874     // BitBLT Alpha Value Selection Register
#define REG1876_BLT_ALPHA_MAP        0x1876     // BitBLT Alpha Combine Alpha Map Register
#define REG1880_BLT_IRQ_STATUS       0x1880     // BitBLT Interrupt Status Register
#define REG1882_BLT_IRQ_CONTROL      0x1882     // BitBLT Interrupt Control Register
#define REG1890_BLT_FIFO_STATUS0     0x1890     // BitBLT FIFO Status Register 0
#define REG1892_BLT_FIFO_STATUS1     0x1892     // BitBLT FIFO Status Register 1
#define REG1894_BLT_FIFO_STATUS2     0x1894     // BitBLT FIFO Status Register 2
#define REG1896_BLT_FIFO_PORT        0x1896     // BitBLT FIFO Data Port Register
#define REG1900_BLT_EXP_LUT          0x1900     // BitBLT Color Expansion LUT Data Register
#define REG_BITBLT_END               0x1902

//
// Memory Controller Registers
//
#define REG_MEMORY_BASE              0x1C00     // MEMORY CONTROLLER REGISTERS
#define REG1C00_MEM_CONTROL          0x1C00     // Memory Control Register
#define REG1C02_MEM_CONFIG_0         0x1C02     // Memory Configuration Register 0
#define REG1C04_MEM_CONFIG_1         0x1C04     // Memory Configuration Register 1
#define REG1C06_MEM_CONFIG_2         0x1C06     // Memory Configuration Register 2
#define REG1C08_MEM_ADV_CONFIG       0x1C08     // Memory Advanced Configuration Register
#define REG1C0A_MEM_INIT_CONFIG      0x1C0A     // Memory Initialization Configuration Register
#define REG1C0C_MEM_REFRESH          0x1C0C     // Memory Refresh Timer Register
#define REG1C10_MEM_SDRAM_MODE       0x1C10     // SDRAM Mode Setting Value Register [READONLY]
#define REG1C12_MEM_SDRAM_CONFIG     0x1C12     // Mobile SDRAM Configuration Register
#define REG1C14_MEM_SDRAM_EXTEND     0x1C14     // Mobile SDRAM Extended Mode Register [READONLY]
#define REG_MEMORY_END               0x1C16

//
// Camera Interface Registers
//
#define REG_CAMERA_BASE              0x2000     // CAMERA INTERFACE REGISTERS
#define REG2000_CAM1_CLOCK           0x2000     // Camera1 Clock Setting Register
#define REG2002_CAM1_SIGNAL          0x2002     // Camera1 Signal Setting Register
#define REG2004_CAM2_CLOCK           0x2004     // Camera2 Clock Setting Register
#define REG2006_CAM2_SIGNAL          0x2006     // Camera2 Signal Setting Register
#define REG2010_CAM_MODE             0x2010     // Camera Mode Setting Register
#define REG2012_CAM_FRAME            0x2012     // Camera Frame Setting Register
#define REG2014_CAM_CONTROL          0x2014     // Camera Control Register [WRITEONLY]
#define REG2016_CAM_STATUS           0x2016     // Camera Status Register [READONLY]
#define REG2020_STROBE_DELAY         0x2020     // Strobe Control Signal Output Delay Setting Register
#define REG2022_STROBE_WIDTH         0x2022     // Strobe Control Signal Pulse Width Setting Register
#define REG2024_STROBE_SETTING       0x2024     // Strobe Setting Register
#define REG_CAMERA_END               0x2026

//
// Resizer Operation Registers
//
#define REG_RESIZER_BASE             0x2430     // RESIZER OPERATION REGISTERS
#define REG2430_RESIZER_CONTROL      0x2430     // Global Resizer Control Register
#define REG2440_VR_CONTROL           0x2440     // View Resizer Control Register
#define REG2444_VR_START_X           0x2444     // View Resizer Start X Position Register
#define REG2446_VR_START_Y           0x2446     // View Resizer Start Y Position Register
#define REG2448_VR_END_X             0x2448     // View Resizer End X Position Register
#define REG244A_VR_END_Y             0x244A     // View Resizer End Y Position Register
#define REG244C_VR_SCALING_RATE      0x244C     // View Resizer Scaling Rate Register
#define REG244E_VR_SCALING_MODE      0x244E     // View Resizer Scaling Mode Register
#define REG2460_CR_CONTROL           0x2460     // Capture Resizer Control Register
#define REG2464_CR_START_X           0x2464     // Capture Resizer Start X Position Register
#define REG2466_CR_START_Y           0x2466     // Capture Resizer Start Y Position Register
#define REG2468_CR_END_X             0x2468     // Capture Resizer End X Position Register
#define REG246A_CR_END_Y             0x246A     // Capture Resizer End Y Position Register
#define REG246C_CR_SCALING_RATE      0x246C     // Capture Resizer Scaling Rate Register
#define REG246E_CR_SCALING_MODE      0x246E     // Capture Resizer Scaling Mode Register
#define REG_RESIZER_END              0x2470

//
// YUV Capture Registers
//
#define REG_YUVCAPTURE_BASE          0x2800     // YUV CAPTURE MODULE REGISTERS
#define REG2800_CAPT_CONTROL         0x2800     // YUV Capture Control Register
#define REG2802_CAPT_STATUS          0x2802     // YUV Capture Status Flag Register
#define REG2804_CAPT_RAW_STATUS      0x2804     // YUV Capture Raw Status Flag Register [READONLY]
#define REG2806_CAPT_IRQ_CONTROL     0x2806     // YUV Capture Interrupt Control Register
#define REG280A_CAPT_START_STOP      0x280A     // YUV Capture Start/Stop Control Register [WRITEONLY]
#define REG2820_CAPT_FIFO_CTRL       0x2820     // YUV Capture FIFO Control Register [WRITEONLY]
#define REG2822_CAPT_FIFO_STATUS     0x2822     // YUV Capture FIFO Status Register [READONLY]
#define REG2826_CAPT_FIFO_PORT       0x2826     // YUV Capture FIFO Read/Write Port Register
#define REG282A_CAPT_FIFO_READ       0x282A     // YUV Capture FIFO Read Pointer Register [READONLY]
#define REG282C_CAPT_FIFO_WRITE      0x282C     // YUV Capture FIFO Write Pointer Register [READONLY]
#define REG282E_CAPT_FIFO_EXTEND     0x282E     // YUV Capture FIFO Extend Register [READONLY]
#define REG2872_CAPT_YUV_X_SIZE      0x2872     // YUV Capture X Size Register
#define REG2874_CAPT_YUV_Y_SIZE      0x2874     // YUV Capture Y Size Register
#define REG_YUVCAPTURE_END           0x2876

//
// YRC Registers
//
#define REG_YRC_BASE                 0x3000     // YRC CONVERTER REGISTERS
#define REG3000_YRC_TRANSLATE        0x3000     // YRC Translate Mode Register
#define REG3002_YRC_SADDR0_0         0x3002     // YRC RAM Interface Write Start Address 0 Register 0
#define REG3004_YRC_SADDR0_1         0x3004     // YRC RAM Interface Write Start Address 0 Register 1
#define REG3006_YRC_SADDR1_0         0x3006     // YRC RAM Interface Write Start Address 1 Register 0
#define REG3008_YRC_SADDR1_1         0x3008     // YRC RAM Interface Write Start Address 1 Register 1
#define REG300A_YRC_SADDR2_0         0x300A     // YRC RAM Interface Write Start Address 2 Register 0 [RESERVED]
#define REG300C_YRC_SADDR2_1         0x300C     // YRC RAM Interface Write Start Address 2 Register 1 [RESERVED]
#define REG300E_YRC_UV_DATA_FIX      0x300E     // YRC UV Data Fix Register
#define REG3010_YRC_RECT_WIDTH       0x3010     // YRC RAM Interface Rectangular Pixel Width Register
#define REG3012_YRC_RECT_STRIDE      0x3012     // YRC RAM Interface Rectangular Line Address Offset Register
#define REG3014_YRC_MEM_CONFIG       0x3014     // YRC Memory Configuration Register [READONLY]
#define REG_YRC_END                  0x3016

//
// PWM Registers
//
#define REG_PWM_BASE                 0x3400     // PWM REGISTERS
#define REG3400_PWM_CONTROL          0x3400     // PWM Control Register
#define REG3402_PWM_CLOCK_DIVIDE     0x3402     // PWM Clock Divide Register
#define REG3404_PWM_RED_CONTROL      0x3404     // PWM Red On/Off Control Register
#define REG3406_PWM_GRN_CONTROL      0x3406     // PWM Green On/Off Control Register
#define REG3408_PWM_BLU_CONTROL      0x3408     // PWM Blue On/Off Control Register
#define REG340A_PWM_SLOPE            0x340A     // PWM Slope Setting Register
#define REG340C_PWM_DUTY_CYCLE       0x340C     // PWM Duty Cycle Setting Register
#define REG340E_PWM_WHITE_CTRL       0x340E     // PWM White LED Control Register
#define REG3410_PWM_ENABLE           0x3410     // PWM Enable Register
#define REG_PWM_END                  0x3412

//
// I2C Registers
//
#define REG_I2C_BASE                 0x3800     // I2C REGISTERS
#define REG3800_I2C_CONTROL          0x3800     // I2C Control Register
#define REG3804_I2C_TARGET_ADDR      0x3804     // I2C Target Address Register
#define REG3810_I2C_RX_TX            0x3810     // I2C RX/TX Data Buffer and Commmand Register
#define REG3814_STAND_I2C_HIGH       0x3814     // Standard Speed I2C Clock SCL High Count Register
#define REG3818_STAND_I2C_LOW        0x3818     // Standard Speed I2C Clock SCL Low Count Register
#define REG381C_FAST_I2C_HIGH        0x381C     // Fast Speed I2C Clock SCL High Count Register
#define REG3820_FAST_I2C_LOW         0x3820     // Fast Speed I2C Clock SCL Low Count Register
#define REG382C_I2C_IRQ_STATUS       0x382C     // I2C Interrupt Status Register
#define REG3830_I2C_IRQ_MASK         0x3830     // I2C Interrupt Mask Register
#define REG3834_I2C_RAW_IRQ_STAT     0x3834     // I2C Raw Interrupt Status Register
#define REG3838_I2C_RX_FIFO          0x3838     // I2C Receive FIFO Threshold Register
#define REG383C_I2C_TX_FIFO          0x383C     // I2C Transmit FIFO Threshold Register
#define REG3840_I2C_CLEAR_IRQ        0x3840     // I2C Clear Combined and Individual Interrupt Register
#define REG3844_I2C_RX_UNDER         0x3844     // I2C Clear RX_UNDER Interrupt Register [READONLY]
#define REG3848_I2C_RX_OVER          0x3848     // I2C Clear RX_OVER Interrupt Register [READONLY]
#define REG3850_I2C_RD_REQ           0x3850     // I2C Clear RD_REQ Interrupt Register [READONLY]
#define REG3854_I2C_TX_ABRT          0x3854     // I2C Clear TX_ABRT Interrupt Register [READONLY]
#define REG3858_I2C_RX_DONE          0x3858     // I2C Clear RX_DONE Interrupt Register [READONLY]
#define REG385C_I2C_ACTIVITY         0x385C     // I2C ACTIVITY Status Interrupt Register [READONLY]
#define REG3860_I2C_STOP_DET         0x3860     // I2C Clear STOP_DET Interrupt Register [READONLY]
#define REG3864_I2C_START_DET        0x3864     // I2C Clear START_DET Interrupt Register [READONLY]
#define REG386C_I2C_ENABLE           0x386C     // I2C Enable Register
#define REG3870_I2C_STATUS           0x3870     // I2C Status Register [READONLY]
#define REG3874_I2C_TX_FIFO_LVL      0x3874     // I2C Transmit FIFO Level Register [READONLY]
#define REG3878_I2C_RX_FIFO_LVL      0x3878     // I2C Receive FIFO Level Register [READONLY]
#define REG3880_I2C_TX_ABORT         0x3880     // I2C Transmit Abort Source Register
#define REG3888_I2C_DMA_CONTROL      0x3888     // I2C DMA Control Register
#define REG388C_I2C_DMA_TX_LEVEL     0x388C     // I2C DMA Transmit Data Level Register
#define REG3890_I2C_DMA_RX_LEVEL     0x3890     // I2C DMA Receive Data Level Register
#define REG38F4_I2C_COMP_PARAM_0     0x38F4     // I2C Component Parameter Register 0 [READONLY]
#define REG38F6_I2C_COMP_PARAM_1     0x38F6     // I2C Component Parameter Register 1 [READONLY]
#define REG38F8_I2C_COMP_VER_0       0x38F8     // I2C Component Version Register 0 [READONLY]
#define REG38FA_I2C_COMP_VER_1       0x38FA     // I2C Component Version Register 1 [READONLY]
#define REG38FC_I2C_COMP_TYPE_0      0x38FC     // I2C Component Type Register 0 [READONLY]
#define REG38FE_I2C_COMP_TYPE_1      0x38FE     // I2C Component Type Register 1 [READONLY]
#define REG_I2C_END                  0x3900

//
// DMA Control Registers
//
#define REG_DMA_BASE                 0x3C00     // DMA CONTROL REGISTERS
#define REG3C00_DMA_CH0_SRC_0        0x3C00     // DMAC Channel 0 Source Address Register 0
#define REG3C02_DMA_CH0_SRC_1        0x3C02     // DMAC Channel 0 Source Address Register 1
#define REG3C04_DMA_CH0_DES_0        0x3C04     // DMAC Channel 0 Destination Address Register 0
#define REG3C06_DMA_CH0_DES_1        0x3C06     // DMAC Channel 0 Destination Address Register 1
#define REG3C08_DMA_CH0_COUNT_0      0x3C08     // DMAC Channel 0 Transfer Count Register 0
#define REG3C0A_DMA_CH0_COUNT_1      0x3C0A     // DMAC Channel 0 Transfer Count Register 1
#define REG3C0C_DMA_CH0_CTRL_0       0x3C0C     // DMAC Channel 0 Control Register 0
#define REG3C0E_DMA_CH0_CTRL_1       0x3C0E     // DMAC Channel 0 Control Register 1
#define REG3C10_DMA_CH1_SRC_0        0x3C10     // DMAC Channel 1 Source Address Register 0
#define REG3C12_DMA_CH1_SRC_1        0x3C12     // DMAC Channel 1 Source Address Register 1
#define REG3C14_DMA_CH1_DES_0        0x3C14     // DMAC Channel 1 Destination Address Register 0
#define REG3C16_DMA_CH1_DES_1        0x3C16     // DMAC Channel 1 Destination Address Register 1
#define REG3C18_DMA_CH1_COUNT_0      0x3C18     // DMAC Channel 1 Transfer Count Register 0
#define REG3C1A_DMA_CH1_COUNT_1      0x3C1A     // DMAC Channel 1 Transfer Count Register 1
#define REG3C1C_DMA_CH1_CTRL_0       0x3C1C     // DMAC Channel 1 Control Register 0
#define REG3C1E_DMA_CH1_CTRL_1       0x3C1E     // DMAC Channel 1 Control Register 1
#define REG3C60_DMA_CH_OPERATING     0x3C60     // DMAC Channel Operating Select Register
#define REG3C64_DMA_CH_MISC          0x3C64     // DMAC Channel Miscellaneous Register
#define REG3C70_DMA_CH_COMPLETE      0x3C70     // DMAC Channel Transfer Complete Control Register
#define REG_DMA_END                  0x3C72

//
// Keypad Interface Register
//
#define REG_KEY_BASE                 0x5000     // KEY INTERFACE REGISTERS
#define REG5000_KEY_CONTROL          0x5000     // Key Control Register
#define REG5002_KEY_IRQ_STATUS       0x5002     // Key Inteface Interrupt Status Register [READONLY]
#define REG5004_KEY_SCAN_DATA        0x5004     // Key Scan Data Register [READONLY]
#define REG5006_KEY_SCAN_CLOCK       0x5006     // Key Scan Input Filter Clock Register
#define REG5008_KEY_GPI_CONTROL      0x5008     // Key GPI Control Register
#define REG500A_KEY_SCAN_OUTPUT      0x500A     // Key Scan Output Control Register
#define REG500C_KEY_GPI_FILTER       0x500C     // Key Scan GPI Filtered Register
#define REG500E_KEY_REENABLE         0x500E     // Key Scan Re-Enable Register
#define REG_KEY_END                  0x5010

/*********************************************************************
*
*       Types
*
**********************************************************************
*/
typedef struct DRIVER_CONTEXT DRIVER_CONTEXT;

/*********************************************************************
*
*       MANAGE_VMEM_API
*/
typedef struct {
  //
  // Private function pointers
  //
  void (* pfSetAddrR)     (DRIVER_CONTEXT * pContext, int x, int y);                      // Sets the address to be read
  void (* pfSetAddrW)     (DRIVER_CONTEXT * pContext, int x, int y);                      // Sets the address to be written
  void (* pfSetRectR)     (DRIVER_CONTEXT * pContext, int x0, int y0, int x1, int y1);    // Sets the rectangular area to be read
  void (* pfSetRectW)     (DRIVER_CONTEXT * pContext, int x0, int y0, int x1, int y1);    // Sets the rectangular area to be written
  void (* pfFlushBuffer)  (DRIVER_CONTEXT * pContext);                                    // Sends remaining data of the write buffer to the controller
  void (* pfWriteData32)  (DRIVER_CONTEXT * pContext, U32 Data);                          // Writes one 32 bit data item using the write buffer
  void (* pfWriteData32M) (DRIVER_CONTEXT * pContext, U32 Data, U32 NumPixels);           // Writes a number of 32 bit items of the same color using the write buffer
  void (* pfWriteData32MP)(DRIVER_CONTEXT * pContext, U32 const * pData, U32 NumPixels);  // Writes 32 bit data using the write buffer
} MANAGE_VMEM_API;

/*********************************************************************
*
*       DRIVER_CONTEXT
*/
struct DRIVER_CONTEXT {
  //
  // Common data
  //
  int xSize, ySize;
  int vxSize, vySize;
  int xPos, yPos;
  int MemSize;
  int SwapXY;
  int XOff;
  U32 BufferOffset;
  int NumBytesInBuffer;
  int IsVisible;
  //
  // Driver specific data
  //
  int WriteBufferSize;
  int UseLayer;
  //
  // Accelerators for calculation
  //
  int BitsPerPixel;
  int BytesPerPixel;
  //
  // VRAM
  //
  U16 * pWriteBuffer;
  U16 * pWrite;
  //
  // API-Tables
  //
  MANAGE_VMEM_API ManageVMEM_API; // Memory management
  GUI_PORT_API    HW_API;         // Hardware routines
};

/*********************************************************************
*
*       LOG2PHYS_xxx
*/
#define LOG2PHYS_X      (                  x    )
#define LOG2PHYS_X_OX   (pContext->xSize - x - 1)
#define LOG2PHYS_X_OY   (                  x    )
#define LOG2PHYS_X_OXY  (pContext->xSize - x - 1)
#define LOG2PHYS_X_OS   (                  y    )
#define LOG2PHYS_X_OSX  (pContext->ySize - y - 1)
#define LOG2PHYS_X_OSY  (                  y    )
#define LOG2PHYS_X_OSXY (pContext->ySize - y - 1)

#define LOG2PHYS_Y      (                  y    )
#define LOG2PHYS_Y_OX   (                  y    )
#define LOG2PHYS_Y_OY   (pContext->ySize - y - 1)
#define LOG2PHYS_Y_OXY  (pContext->ySize - y - 1)
#define LOG2PHYS_Y_OS   (                  x    )
#define LOG2PHYS_Y_OSX  (                  x    )
#define LOG2PHYS_Y_OSY  (pContext->xSize - x - 1)
#define LOG2PHYS_Y_OSXY (pContext->xSize - x - 1)

/*********************************************************************
*
*       _SetPixelIndex_##EXT
*/
#if (GUI_VERSION < 53400)

#define IMPLEMENT_SETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                                   \
static void _SetPixelIndex_##EXT(GUI_DEVICE * pDevice, int x, int y, int PixelIndex) { \
  DRIVER_CONTEXT * pContext;                                                           \
                                                                                       \
  pContext = (DRIVER_CONTEXT *)pDevice->u.pContext;                                    \
  _SetPixelIndex(pContext, X_PHYS, Y_PHYS, PixelIndex);                                \
}

#else

#define IMPLEMENT_SETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                                              \
static void _SetPixelIndex_##EXT(GUI_DEVICE * pDevice, int x, int y, LCD_PIXELINDEX PixelIndex) { \
  DRIVER_CONTEXT * pContext;                                                                      \
                                                                                                  \
  pContext = (DRIVER_CONTEXT *)pDevice->u.pContext;                                               \
  _SetPixelIndex(pContext, X_PHYS, Y_PHYS, PixelIndex);                                           \
}

#endif

/*********************************************************************
*
*       _GetPixelIndex_##EXT
*/
#if (GUI_VERSION < 53400)

#define IMPLEMENT_GETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                           \
static unsigned int _GetPixelIndex_##EXT(GUI_DEVICE * pDevice, int x, int y) { \
  DRIVER_CONTEXT * pContext;                                                   \
  LCD_PIXELINDEX PixelIndex;                                                   \
                                                                               \
  pContext = (DRIVER_CONTEXT *)pDevice->u.pContext;                            \
  PixelIndex = _GetPixelIndex(pContext, X_PHYS, Y_PHYS);                       \
  return PixelIndex;                                                           \
}

#else

#define IMPLEMENT_GETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                             \
static LCD_PIXELINDEX _GetPixelIndex_##EXT(GUI_DEVICE * pDevice, int x, int y) { \
  DRIVER_CONTEXT * pContext;                                                     \
  LCD_PIXELINDEX PixelIndex;                                                     \
                                                                                 \
  pContext = (DRIVER_CONTEXT *)pDevice->u.pContext;                              \
  PixelIndex = _GetPixelIndex(pContext, X_PHYS, Y_PHYS);                         \
  return PixelIndex;                                                             \
}

#endif

/*********************************************************************
*
*       _GetDevProp_##EXT
*/
#define IMPLEMENT_GETDEVPROP(EXT, MX, MY, SWAP)                 \
static I32 _GetDevProp_##EXT(GUI_DEVICE * pDevice, int Index) { \
  switch (Index) {                                              \
  case LCD_DEVCAP_MIRROR_X: return MX;                          \
  case LCD_DEVCAP_MIRROR_Y: return MY;                          \
  case LCD_DEVCAP_SWAP_XY:  return SWAP;                        \
  }                                                             \
  return _GetDevProp(pDevice, Index);                           \
}

/*********************************************************************
*
*       IMPLEMENT_FUNCTIONS
*/
#define IMPLEMENT_FUNCTIONS(EXT, X_PHYS, Y_PHYS, MX, MY, SWAP) \
  IMPLEMENT_SETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                 \
  IMPLEMENT_GETPIXELINDEX(EXT, X_PHYS, Y_PHYS)                 \
  IMPLEMENT_GETDEVPROP(EXT, MX, MY, SWAP)                      \
  IMPLEMENT_GUI_DEVICE_API(EXT)

/*********************************************************************
*
*       Private functions
*
**********************************************************************
*/
void (*GUIDRV__S1D13513_GetDevFunc(GUI_DEVICE ** ppDevice, int Index))(void);
void   GUIDRV__S1D13513_SetOrg    (GUI_DEVICE *  pDevice,  int x, int y);
I32    GUIDRV__S1D13513_GetDevProp(GUI_DEVICE *  pDevice,  int Index);
void   GUIDRV__S1D13513_GetRect   (GUI_DEVICE *  pDevice,  LCD_RECT * pRect);

#if defined(__cplusplus)
}
#endif

#endif /* GUIDRV_S1D13513_PRIVATE_H */

/*************************** End of file ****************************/
